# TrinityCore - WowPacketParser
# File name: DarkmoonMulgoreOpenSteamtonkController_(1.13.3.33155).pkt
# Detected build: V1_13_3_33155
# Detected locale: enUS
# Targeted database: Classic
# Parsing date: 03/14/2021 10:43:45

SET @ACCID = 0; 
SET @CGUID = 0; 
SET @DGUID = 0;
SET @IGUID = 0; 
SET @OGUID = 0; 
SET @PGUID = 0; 
SET @POIID = 0; 
SET @LOOTID = 0; 
SET @SNIFFID = 0; 

DELETE FROM `player` WHERE `guid` BETWEEN @PGUID+0 AND @PGUID+1885;
INSERT INTO `player` (`guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `name`, `race`, `class`, `gender`, `level`, `xp`, `money`, `player_bytes1`, `player_bytes2`, `player_flags`, `pvp_rank`, `scale`, `display_id`, `native_display_id`, `mount_display_id`, `faction`, `unit_flags`, `unit_flags2`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `move_flags`, `speed_walk`, `speed_run`, `speed_run_back`, `speed_swim`, `speed_swim_back`, `speed_fly`, `speed_fly_back`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `ranged_attack_time`, `channel_spell_id`, `channel_visual_id`, `equipment_cache`, `auras`) VALUES
(@PGUID+1883, 1, -1578.145, 153.5279, -7.775026, 3.846091, 'Mjomqvaa', 3, 4, 1, 32, 0, 0, 118030592, 50331648, 1, 0, 1, 54, 54, 0, 3, 8, 2048, 100, 100, 100, 100, 4194304, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 2400, 2800, 2000, 0, 0, '7997 0 5002 0 4252 0 49 0 2041 0 10403 0 9624 0 1121 0 3202 0 9832 0 1156 0 2933 0 0 0 0 0 5193 0 15213 0 5191 0 3567 0 0 0', '23768 23770 21184 16092 20595 20596 13863 13712 13793 13856 2836 13845 13851 13961 9141 7492 7504 7490 7466'),
(@PGUID+1885, 1, -1582.936, 150.3409, -7.599892, 3.568506, 'Qkuxjkzg', 6, 11, 0, 60, 0, 0, 1, 0, 134217728, 458752, 1, 59, 59, 14349, 6, 8, 2048, 100, 100, 3274, 3274, 4194304, 0, 0, 0, 0, 0, 0, 0, 1, 2.03, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 3100, 2000, 2000, 0, 0, '10226 0 19095 0 13116 0 5107 0 10220 0 19089 0 15062 0 10146 0 16830 0 15063 0 12015 0 12016 0 11122 0 17907 0 18461 0 19101 0 0 0 0 0 19031 0', '23247 2383 20552 20551 20550 17249 16920 16906 16835 16862 16933 16975 16999 24894 17007 17053 9344 15465 9396 21596 13669 9100 9117 14371 14465 7850 14371 14465 13587 9259 9264 9335 7597 9330 15811 7597 9098 9115'),
(@PGUID+1882, 1, -1532.315, 154.7265, -7.772223, 0.2962068, 'Qwqjmcgq', 6, 1, 0, 2, 655, 4329, 34013696, 100663296, 0, 0, 1, 59, 59, 0, 6, 8, 2048, 99, 99, 0, 1000, 0, 0, 0, 0, 0, 0, 17, 2048, 1, 1, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2900, 2000, 0, 0, 0, '0 0 0 0 0 0 6125 0 0 0 0 0 139 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2361 0 0 0 0 0 0 0', '2457 21156'),
(@PGUID+1884, 1, -1578.732, 149.4188, -7.651361, 3.893186, 'Kvsnojqj', 7, 9, 1, 34, 0, 0, 84017923, 33554432, 2, 0, 1, 1564, 1564, 0, 115, 8, 2048, 100, 100, 2317, 2317, 4194304, 0, 1, 0, 2, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 1600, 2000, 2000, 0, 0, '4323 0 10299 0 9796 0 6097 0 14120 0 10404 0 2277 0 9845 0 6613 0 9609 0 9461 0 2933 0 0 0 0 0 9794 0 7005 0 1131 0 5244 0 0 0', '30794 20592 20593 20591 17814 18176 18183 17787 17808 18218 18095 7617 7709 7710 22747 7708 7708 7710 7710 7496 7503 9414 9106 7494 7506');

DELETE FROM `player_guid_values` WHERE `guid` BETWEEN @PGUID+0 AND @PGUID+1885;
INSERT INTO `player_guid_values` (`guid`, `charm_guid`, `charm_id`, `charm_type`, `summon_guid`, `summon_id`, `summon_type`, `charmer_guid`, `charmer_id`, `charmer_type`, `summoner_guid`, `summoner_id`, `summoner_type`, `creator_guid`, `creator_id`, `creator_type`, `demon_creator_guid`, `demon_creator_id`, `demon_creator_type`, `target_guid`, `target_id`, `target_type`) VALUES
(@PGUID+1885, 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+1883, 0, 'Player');

DELETE FROM `player_active_player` WHERE (`unixtime`=1581499026 AND `guid`='@PGUID+1882');
INSERT INTO `player_active_player` (`unixtime`, `guid`) VALUES
(1581499026, @PGUID+1882);

INSERT INTO `player_create1_time` (`unixtimems`, `guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1581499026719, @PGUID+1883, 1, -1578.145, 153.5279, -7.775026, 3.846091),
(1581499026875, @PGUID+1885, 1, -1582.936, 150.3409, -7.599892, 3.568506),
(1581499026719, @PGUID+1884, 1, -1578.732, 149.4188, -7.651361, 3.893186);

INSERT INTO `player_create2_time` (`unixtimems`, `guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1581499026719, @PGUID+1882, 1, -1532.315, 154.7265, -7.772223, 0.2962068);

INSERT INTO `player_movement_client` (`unixtimems`, `guid`, `opcode`, `move_time`, `move_flags`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1581499026984, @PGUID+1882, 'CMSG_MOVE_FALL_LAND', 416385552, 0, 1, -1532.315, 154.7265, -7.772223, 0.2962068),
(1581499028266, @PGUID+1882, 'CMSG_MOVE_START_FORWARD', 416386898, 1, 1, -1532.315, 154.7265, -7.772223, 0.2962068),
(1581499028547, @PGUID+1882, 'CMSG_MOVE_START_STRAFE_LEFT', 416387165, 5, 1, -1530.527, 155.272, -7.71781, 0.2962068),
(1581499029031, @PGUID+1882, 'CMSG_MOVE_HEARTBEAT', 416387665, 5, 1, -1528.882, 158.3615, -7.792142, 0.2962068),
(1581499029047, @PGUID+1882, 'CMSG_MOVE_STOP_STRAFE', 416387680, 1, 1, -1528.833, 158.4542, -7.792142, 0.2962068),
(1581499029562, @PGUID+1882, 'CMSG_MOVE_HEARTBEAT', 416388180, 1, 1, -1525.485, 159.4758, -7.78994, 0.2962068),
(1581499029719, @PGUID+1882, 'CMSG_MOVE_STOP', 416388344, 0, 1, -1524.387, 159.8109, -7.789398, 0.2962068),
(1581499030672, @PGUID+1882, 'CMSG_MOVE_FORCE_ROOT_ACK', 416389298, 1024, 1, -1524.387, 159.8109, -7.789398, 0.2962068),
(1581499062625, @PGUID+1882, 'CMSG_MOVE_FORCE_UNROOT_ACK', 416421257, 0, 1, -1524.387, 159.8109, -7.789398, 0.2962068),
(1581499062641, @PGUID+1882, 'CMSG_MOVE_FORCE_ROOT_ACK', 416421257, 1024, 1, -1524.387, 159.8109, -7.789398, 0.2962068),
(1581499063844, @PGUID+1882, 'CMSG_MOVE_SPLINE_DONE', 416422458, 526336, 1, -1524.387, 159.8109, -7.789398, 0.2962068),
(1581499064000, @PGUID+1882, 'CMSG_MOVE_SPLINE_DONE', 416422624, 526336, 1, -1524.387, 159.8109, -7.789398, 0.2962068),
(1581499065703, @PGUID+1882, 'CMSG_MOVE_FORCE_UNROOT_ACK', 416424328, 2048, 1, -1524.387, 159.8109, -7.789398, 0.2962068),
(1581499068297, @PGUID+1883, 'SMSG_MOVE_UPDATE', 951104209, 1, 1, -1578.145, 153.5279, -7.775026, 3.850018),
(1581499068578, @PGUID+1883, 'SMSG_MOVE_UPDATE', 951104439, 5, 1, -1578.36, 151.965, -7.739837, 3.853945),
(1581499068703, @PGUID+1883, 'SMSG_MOVE_UPDATE', 951104646, 5, 1, -1578.445, 150.5236, -7.699098, 3.869653),
(1581499069016, @PGUID+1883, 'SMSG_MOVE_UPDATE', 951104887, 5, 1, -1578.517, 148.8386, -7.633205, 3.889288),
(1581499069266, @PGUID+1883, 'SMSG_MOVE_UPDATE', 951105132, 5, 1, -1578.604, 147.1264, -7.547626, 3.779332),
(1581499069406, @PGUID+1883, 'SMSG_MOVE_UPDATE', 951105273, 1, 1, -1579.246, 146.4876, -7.489114, 3.594763);

INSERT INTO `player_movement_server` (`unixtimems`, `guid`, `point`, `move_time`, `spline_flags`, `spline_count`, `start_position_x`, `start_position_y`, `start_position_z`, `end_position_x`, `end_position_y`, `end_position_z`, `orientation`) VALUES
(1581499026875, @PGUID+1882, 1, 0, 0, 0, -1532.315, 154.7265, -7.772223, 0, 0, 0, 100),
(1581499032437, @PGUID+1882, 2, 0, 0, 0, -1524.387, 159.8109, -7.789398, 0, 0, 0, 100),
(1581499063187, @PGUID+1882, 3, 0, 0, 0, -1524.387, 159.8109, -7.789398, 0, 0, 0, 100),
(1581499063984, @PGUID+1882, 4, 0, 0, 0, -1524.387, 159.8109, -7.789398, 0, 0, 0, 100);


INSERT INTO `player_guid_values_update` (`unixtimems`, `guid`, `field_name`, `object_guid`, `object_id`, `object_type`) VALUES
(1581499032297, @PGUID+1882, 'Charm', @CGUID+3997, 15328, 'Creature'),
(1581499063844, @PGUID+1882, 'Charm', 0, 0, '');

INSERT INTO `player_auras_update` (`unixtimems`, `guid`, `update_id`, `slot`, `spell_id`, `visual_id`, `aura_flags`, `active_flags`, `level`, `charges`, `duration`, `max_duration`, `caster_guid`, `caster_id`, `caster_type`) VALUES
(1581499026719, @PGUID+1883, 1, 0, 23768, 247176, 6, 1, 55, 0, 0, 0, @CGUID+3991, 14822, 'Creature'),
(1581499026719, @PGUID+1883, 1, 32, 23770, 0, 20, 1, 55, 0, 0, 0, @CGUID+3991, 14822, 'Creature'),
(1581499026719, @PGUID+1883, 1, 48, 21184, 0, 1, 1, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 49, 16092, 0, 1, 1, 29, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 50, 20595, 0, 1, 1, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 51, 20596, 0, 1, 1, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 52, 13863, 0, 1, 1, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 53, 13712, 0, 1, 1, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 54, 13793, 0, 1, 1, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 55, 13856, 0, 1, 1, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 56, 2836, 0, 1, 3, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 57, 13845, 0, 1, 1, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 58, 13851, 0, 1, 1, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 59, 13961, 0, 1, 1, 32, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 60, 9141, 0, 1, 3, 24, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 61, 7492, 0, 1, 1, 31, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 62, 7504, 0, 1, 1, 31, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 63, 7490, 0, 1, 1, 36, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1883, 1, 64, 7466, 0, 1, 1, 36, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 0, 23247, 249459, 3, 3, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 1, 2383, 0, 3, 1, 63, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 48, 20552, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 49, 20551, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 50, 20550, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 51, 17249, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 52, 16920, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 53, 16906, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 54, 16835, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 55, 16862, 0, 1, 3, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 56, 16933, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 57, 16975, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 58, 16999, 0, 1, 3, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 59, 24894, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 60, 17007, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 61, 17053, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 62, 9344, 0, 1, 3, 65, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 63, 15465, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 64, 9396, 0, 1, 3, 66, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 65, 21596, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 66, 13669, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 67, 9100, 0, 1, 1, 61, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 68, 9117, 0, 1, 1, 61, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 69, 14371, 0, 1, 1, 61, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 70, 14465, 0, 1, 1, 61, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 73, 7850, 0, 1, 1, 63, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 74, 14371, 0, 1, 1, 63, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 75, 14465, 0, 1, 1, 63, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 76, 13587, 0, 1, 1, 50, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 77, 9259, 0, 1, 1, 61, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 78, 9264, 0, 1, 1, 61, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 79, 9335, 0, 1, 3, 58, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 80, 7597, 0, 1, 1, 58, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 81, 9330, 0, 1, 3, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 82, 15811, 0, 1, 3, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 83, 7597, 0, 1, 1, 60, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 85, 9098, 0, 1, 1, 57, 0, 0, 0, 0, 0, ''),
(1581499026875, @PGUID+1885, 1, 86, 9115, 0, 1, 1, 57, 0, 0, 0, 0, 0, ''),
(1581499034656, @PGUID+1885, 2, 2, 23767, 247042, 6, 1, 55, 0, 0, 0, @CGUID+3991, 14822, 'Creature'),
(1581499034656, @PGUID+1885, 3, 32, 23770, 0, 20, 1, 55, 0, 0, 0, @CGUID+3991, 14822, 'Creature'),
(1581499026719, @PGUID+1882, 1, 0, 2457, 238278, 3, 1, 1, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1882, 1, 48, 21156, 0, 1, 1, 1, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1882, 2, 0, 2457, 238278, 3, 1, 1, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1882, 2, 48, 21156, 0, 1, 1, 1, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1882, 3, 49, 5301, 0, 1, 1, 1, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1882, 4, 50, 20552, 0, 1, 1, 2, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1882, 5, 51, 20551, 0, 1, 1, 2, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1882, 6, 52, 20550, 0, 1, 1, 2, 0, 0, 0, 0, 0, ''),
(1581499030672, @PGUID+1882, 7, 1, 24935, 0, 6, 2, 0, 0, 300000, 300000, 0, 0, ''),
(1581499031078, @PGUID+1882, 8, 2, 24937, 250246, 7, 6, 2, 0, 300000, 300000, 0, 0, ''),
(1581499062625, @PGUID+1882, 9, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1581499062625, @PGUID+1882, 9, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1581499062625, @PGUID+1882, 9, 32, 27880, 250874, 21, 1, 2, 0, 3000, 3000, 0, 0, ''),
(1581499065703, @PGUID+1882, 10, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 0, 30794, 0, 3, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 48, 20592, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 49, 20593, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 50, 20591, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 51, 17814, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 52, 18176, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 53, 18183, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 54, 17787, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 55, 17808, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 56, 18218, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 57, 18095, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 58, 7617, 0, 1, 1, 25, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 59, 7709, 0, 1, 1, 35, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 60, 7710, 0, 1, 1, 28, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 61, 22747, 0, 1, 3, 4, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 62, 7708, 0, 1, 1, 25, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 63, 7708, 0, 1, 1, 34, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 64, 7710, 0, 1, 1, 20, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 65, 7710, 0, 1, 1, 27, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 66, 7496, 0, 1, 1, 30, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 67, 7503, 0, 1, 1, 30, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 68, 9414, 0, 1, 1, 35, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 69, 9106, 0, 1, 1, 37, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 70, 7494, 0, 1, 1, 31, 0, 0, 0, 0, 0, ''),
(1581499026719, @PGUID+1884, 1, 71, 7506, 0, 1, 1, 31, 0, 0, 0, 0, 0, '');

INSERT INTO `player_values_update` (`unixtimems`, `guid`, `entry`, `scale`, `display_id`, `mount_display_id`, `faction`, `level`, `npc_flags`, `unit_flags`, `unit_flags2`, `dynamic_flags`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `channel_spell_id`, `channel_visual_id`) VALUES
(1581499026719, @PGUID+1882, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 104, 104, NULL, NULL, 4194304, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499030672, @PGUID+1882, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499031391, @PGUID+1882, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 131080, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 24937, 250246),
(1581499063031, @PGUID+1882, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 262152, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0),
(1581499065875, @PGUID+1882, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


INSERT IGNORE INTO `weather_update` (`unixtimems`, `map_id`, `zone_id`, `weather_state`, `grade`, `instant`) VALUES
(1581499026125, 1, 215, 1, 0, 1); -- 1 - Fog - 0

DELETE FROM `client_reclaim_corpse` WHERE `unixtimems` IN (1581473388188, 1581470023203);
INSERT INTO `client_reclaim_corpse` (`unixtimems`) VALUES
(1581473388188),
(1581470023203);


DELETE FROM `client_release_spirit` WHERE `unixtimems` IN (1581471985953, 1581469907235);
INSERT INTO `client_release_spirit` (`unixtimems`) VALUES
(1581471985953),
(1581469907235);


DELETE FROM `world_state_init` WHERE (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=17648 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=17647 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=17223 AND `value`=1) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=2325 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=2324 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=2323 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=2322 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=2264 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=2263 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=2262 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=2261 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=2260 AND `value`=0) OR (`unixtimems`=1581499026125 AND `map`=1 AND `zone_id`=215 AND `area_id`=215 AND `variable`=2259 AND `value`=0);
INSERT INTO `world_state_init` (`unixtimems`, `map`, `zone_id`, `area_id`, `variable`, `value`) VALUES
(1581499026125, 1, 215, 215, 17648, 0),
(1581499026125, 1, 215, 215, 17647, 0),
(1581499026125, 1, 215, 215, 17223, 1),
(1581499026125, 1, 215, 215, 2325, 0),
(1581499026125, 1, 215, 215, 2324, 0),
(1581499026125, 1, 215, 215, 2323, 0),
(1581499026125, 1, 215, 215, 2322, 0),
(1581499026125, 1, 215, 215, 2264, 0),
(1581499026125, 1, 215, 215, 2263, 0),
(1581499026125, 1, 215, 215, 2262, 0),
(1581499026125, 1, 215, 215, 2261, 0),
(1581499026125, 1, 215, 215, 2260, 0),
(1581499026125, 1, 215, 215, 2259, 0);


DELETE FROM `creature` WHERE `guid` BETWEEN @CGUID+0 AND @CGUID+3999;
INSERT INTO `creature` (`guid`, `id`, `map`, `zone_id`, `area_id`, `position_x`, `position_y`, `position_z`, `orientation`, `wander_distance`, `movement_type`, `is_spawn`, `is_hovering`, `is_temporary`, `is_pet`, `summon_spell`, `scale`, `display_id`, `native_display_id`, `mount_display_id`, `class`, `gender`, `faction`, `level`, `npc_flags`, `unit_flags`, `unit_flags2`, `dynamic_flags`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `move_flags`, `speed_walk`, `speed_run`, `speed_run_back`, `speed_swim`, `speed_swim_back`, `speed_fly`, `speed_fly_back`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `main_hand_slot_item`, `off_hand_slot_item`, `ranged_slot_item`, `channel_spell_id`, `channel_visual_id`, `auras`, `sniff_build`) VALUES
(@CGUID+3978, 14841, 1, 215, 215, -1550.856, 141.0691, -7.686889, 2.251475, 0, 0, 0, 0, 0, 0, 0, 1, 14877, 14877, 0, 1, 0, 1555, 55, 3, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155),
(@CGUID+3980, 14828, 1, 215, 215, -1565.044, 131.113, -7.648213, 2.059489, 0, 0, 0, 0, 0, 0, 0, 1, 14854, 14854, 0, 1, 0, 1555, 25, 3, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 12851, 0, 0, 0, '', 33155),
(@CGUID+3979, 10445, 1, 215, 215, -1562.913, 152.3038, -7.709476, 4.031711, 0, 0, 0, 0, 0, 0, 0, 1, 9810, 9810, 0, 1, 1, 1555, 30, 1, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.383, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155),
(@CGUID+3981, 3035, 1, 215, 215, -1522.03, 89.80112, 1.990587, 2.99666, 27.56329, 2, 0, 0, 0, 0, 0, 1, 1059, 1059, 0, 1, 2, 14, 7, 0, 0, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0.8571429, 1, 1, 1, 1, 1, 0.67575, 1.275, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155), --  (possible waypoints or random movement)
(@CGUID+3986, 2957, 1, 215, 215, -1492.707, 125.5521, -0.9092584, 5.557192, 29.13635, 2, 0, 0, 0, 0, 0, 1, 1221, 1221, 0, 1, 2, 189, 9, 0, 0, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0.666668, 1.142857, 1, 1, 1, 1, 1, 0.5729001, 1.275, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155), --  (possible waypoints or random movement)
(@CGUID+3992, 14833, 1, 215, 215, -1477.94, 190.3591, -7.709469, 5.375614, 0, 0, 0, 0, 0, 0, 0, 1, 14875, 14875, 0, 1, 0, 1555, 55, 3, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.383, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155),
(@CGUID+3985, 14849, 1, 215, 215, -1579.879, 166.9071, -7.586904, 4.438963, 69.73133, 2, 0, 0, 0, 0, 0, 1, 14890, 14890, 0, 1, 0, 1555, 25, 1, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 3362, 13604, 0, 0, 0, '', 33155), --  (possible waypoints or random movement)
(@CGUID+3982, 14827, 1, 215, 215, -1574.779, 137.5245, -7.711545, 4.532719, 44.93285, 2, 0, 0, 0, 0, 0, 1, 536, 536, 0, 1, 0, 1555, 60, 3, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 1.56275, 2.625, 1, 2000, 2000, 5287, 0, 0, 0, 0, '', 33155), --  (possible waypoints or random movement)
(@CGUID+3989, 14844, 1, 215, 215, -1585.396, 163.7202, -7.315474, 6.108652, 0, 0, 0, 0, 0, 0, 0, 1, 14880, 14880, 0, 1, 1, 1555, 35, 129, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 13861, 0, 0, 0, 0, '', 33155),
(@CGUID+3991, 14822, 1, 215, 215, -1586.9, 151.3694, -7.492905, 0.4886922, 0, 0, 0, 0, 0, 0, 0, 1, 491, 491, 0, 2, 2, 1555, 55, 3, 768, 2048, 0, 100, 100, 2117, 2117, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.4324, 1.725, 1, 2000, 2000, 12746, 12865, 0, 0, 0, '', 33155),
(@CGUID+3988, 14847, 1, 215, 215, -1579.042, 176.1449, -7.709476, 5.375614, 0, 0, 0, 0, 0, 0, 0, 1, 14883, 14883, 0, 1, 0, 1555, 35, 131, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 12867, 0, 0, 0, '', 33155),
(@CGUID+3990, 14845, 1, 215, 215, -1584.82, 167.7215, -7.370606, 6.073746, 0, 0, 0, 0, 0, 0, 0, 1, 14881, 14881, 0, 1, 0, 1555, 35, 129, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.9747, 4.05, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155),
(@CGUID+3983, 14823, 1, 215, 215, -1575.642, 134.2555, -7.913327, 4.499595, 44.99429, 2, 0, 0, 0, 0, 0, 1, 14855, 14855, 0, 2, 0, 1555, 61, 3, 768, 2048, 0, 100, 100, 2486, 2486, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 2000, 2000, 19214, 0, 0, 0, 0, '', 33155), --  (possible waypoints or random movement)
(@CGUID+3984, 14846, 1, 215, 215, -1575.469, 177.9256, -7.709476, 4.904375, 0, 0, 0, 0, 0, 0, 0, 1, 14882, 14882, 0, 1, 1, 1555, 35, 129, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155),
(@CGUID+3987, 14867, 1, 215, 215, -1555.156, 110.3848, -5.490895, 4.144215, 5.358279, 1, 0, 0, 0, 0, 0, 1, 14938, 14938, 0, 1, 2, 1555, 5, 0, 512, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.3, 0, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155), --  (possible waypoints or random movement)
(@CGUID+3996, 14849, 1, 215, 215, -1604.295, 121.2069, -15.71285, 3.079052, 10.92349, 1, 0, 0, 0, 0, 0, 1, 14912, 14912, 0, 1, 1, 1555, 25, 1, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 3362, 13605, 0, 0, 0, '', 33155), --  (possible waypoints or random movement)
(@CGUID+3993, 14871, 1, 215, 215, -1479.987, 205.2055, -7.709469, 3.281219, 0, 0, 0, 0, 0, 0, 0, 1, 14943, 14943, 0, 1, 1, 1555, 12, 1, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.236, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155),
(@CGUID+3994, 14860, 1, 215, 215, -1466.356, 188.8066, -7.667799, 0.8482341, 160.5233, 2, 0, 0, 0, 0, 0, 1, 14589, 14589, 0, 1, 0, 1555, 4, 129, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0.5, 1, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155), --  (possible waypoints or random movement)
(@CGUID+3995, 14866, 1, 215, 215, -1465.033, 190.3069, -7.667799, 0.8482764, 164.0746, 2, 0, 0, 0, 0, 0, 1, 14936, 14936, 0, 1, 2, 1555, 5, 1, 768, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.2, 0, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155), --  (possible waypoints or random movement)
(@CGUID+3997, 15328, 1, 215, 215, -1524.387, 159.8109, -7.706064, 0.2962068, 7.762078, 1, 1, 0, 1, 0, 24934, 1, 15381, 15381, 0, 2, 2, 1616, 2, 0, 33556480, 0, 0, 100, 100, 100, 100, 0, 0, 0, 0, 1, 0, 0, 0, 1.6, 0.8571429, 1, 1, 1, 1, 1, 0.27, 5, 1, 2000, 2000, 0, 0, 0, 0, 0, '27747', 33155), --  (possible waypoints or random movement)
(@CGUID+3998, 16121, 1, 215, 215, -1498.708, 164.7282, -7.581925, 6.170985, 0, 0, 1, 0, 1, 0, 25003, 1, 15435, 15435, 0, 1, 2, 1617, 1, 0, 33554432, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0.8571429, 1, 1, 1, 1, 1, 0.39, 0, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155),
(@CGUID+3999, 16121, 1, 215, 215, -1498.708, 164.7282, -7.581925, 6.170985, 0, 0, 1, 0, 1, 0, 25003, 1, 15435, 15435, 0, 1, 2, 1617, 1, 0, 33554432, 2048, 0, 100, 100, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0.8571429, 1, 1, 1, 1, 1, 0.39, 0, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33155);

DELETE FROM `creature_guid_values` WHERE `guid` BETWEEN @CGUID+0 AND @CGUID+3999;
INSERT INTO `creature_guid_values` (`guid`, `charm_guid`, `charm_id`, `charm_type`, `summon_guid`, `summon_id`, `summon_type`, `charmer_guid`, `charmer_id`, `charmer_type`, `summoner_guid`, `summoner_id`, `summoner_type`, `creator_guid`, `creator_id`, `creator_type`, `demon_creator_guid`, `demon_creator_id`, `demon_creator_type`, `target_guid`, `target_id`, `target_type`) VALUES
(@CGUID+3997, 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', @PGUID+1882, 0, 'Player', 0, 0, ''),
(@CGUID+3998, 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', @CGUID+3997, 15328, 'Creature', 0, 0, ''),
(@CGUID+3999, 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', @CGUID+3997, 15328, 'Creature', 0, 0, '');

INSERT INTO `creature_create1_time` (`unixtimems`, `guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1581499026719, @CGUID+3978, 1, -1550.856, 141.0691, -7.686889, 2.251475),
(1581499026719, @CGUID+3980, 1, -1565.044, 131.113, -7.648213, 2.059489),
(1581499026719, @CGUID+3979, 1, -1562.913, 152.3038, -7.709476, 4.031711),
(1581499026719, @CGUID+3981, 1, -1522.03, 89.80112, 1.990587, 2.99666),
(1581499026875, @CGUID+3986, 1, -1492.707, 125.5521, -0.9092584, 5.557192),
(1581499026875, @CGUID+3992, 1, -1477.94, 190.3591, -7.709469, 5.375614),
(1581499026875, @CGUID+3985, 1, -1579.879, 166.9071, -7.586904, 4.438963),
(1581499026875, @CGUID+3982, 1, -1574.779, 137.5245, -7.711545, 4.532719),
(1581499026875, @CGUID+3989, 1, -1585.396, 163.7202, -7.315474, 6.108652),
(1581499026875, @CGUID+3991, 1, -1586.9, 151.3694, -7.492905, 0.4886922),
(1581499026875, @CGUID+3988, 1, -1579.042, 176.1449, -7.709476, 5.375614),
(1581499026875, @CGUID+3990, 1, -1584.82, 167.7215, -7.370606, 6.073746),
(1581499026875, @CGUID+3983, 1, -1575.642, 134.2555, -7.913327, 4.499595),
(1581499026875, @CGUID+3984, 1, -1575.469, 177.9256, -7.709476, 4.904375),
(1581499026875, @CGUID+3987, 1, -1555.156, 110.3848, -5.490895, 4.144215),
(1581499027062, @CGUID+3996, 1, -1604.295, 121.2069, -15.71285, 3.079052),
(1581499067906, @CGUID+3996, 1, -1612.447, 114.157, -17.49326, 0.2977283),
(1581499027062, @CGUID+3993, 1, -1479.987, 205.2055, -7.709469, 3.281219),
(1581499027062, @CGUID+3994, 1, -1466.356, 188.8066, -7.667799, 0.8482341),
(1581499064250, @CGUID+3994, 1, -1606.716, 120.4622, -16.27817, 5.793343),
(1581499027062, @CGUID+3995, 1, -1465.033, 190.3069, -7.667799, 0.8482764),
(1581499064250, @CGUID+3995, 1, -1605.262, 122.4646, -15.8727, 5.473028);

INSERT INTO `creature_create2_time` (`unixtimems`, `guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1581499031078, @CGUID+3997, 1, -1524.387, 159.8109, -7.706064, 0.2962068),
(1581499037984, @CGUID+3998, 1, -1498.708, 164.7282, -7.581925, 6.170985),
(1581499049312, @CGUID+3999, 1, -1498.708, 164.7282, -7.581925, 6.170985);

INSERT INTO `creature_destroy_time` (`unixtimems`, `guid`) VALUES
(1581499069016, @CGUID+3983),
(1581499032297, @CGUID+3996),
(1581499059406, @CGUID+3994),
(1581499059406, @CGUID+3995),
(1581499068703, @CGUID+3997),
(1581499040812, @CGUID+3998),
(1581499051734, @CGUID+3999);

INSERT INTO `creature_auras_update` (`unixtimems`, `guid`, `update_id`, `slot`, `spell_id`, `visual_id`, `aura_flags`, `active_flags`, `level`, `charges`, `duration`, `max_duration`, `caster_guid`, `caster_id`, `caster_type`) VALUES
(1581499031078, @CGUID+3997, 1, 48, 27747, 0, 1, 7, 2, 0, 0, 0, 0, 0, ''),
(1581499031078, @CGUID+3997, 2, 48, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1581499031078, @CGUID+3997, 3, 48, 27747, 0, 1, 7, 2, 0, 0, 0, 0, 0, ''),
(1581499031391, @CGUID+3997, 4, 0, 24937, 250246, 6, 1, 2, 0, 0, 0, @PGUID+1882, 0, 'Player'),
(1581499039547, @CGUID+3997, 5, 1, 25026, 0, 3, 1, 2, 0, 0, 0, 0, 0, ''),
(1581499042125, @CGUID+3997, 6, 2, 27746, 249676, 3, 3, 2, 0, 0, 0, 0, 0, ''),
(1581499046141, @CGUID+3997, 7, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1581499046578, @CGUID+3997, 8, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1581499050047, @CGUID+3997, 9, 1, 25026, 0, 3, 1, 2, 0, 0, 0, 0, 0, ''),
(1581499050797, @CGUID+3997, 10, 2, 27746, 249676, 3, 3, 2, 0, 0, 0, 0, 0, ''),
(1581499051047, @CGUID+3997, 11, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1581499051734, @CGUID+3997, 12, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1581499052141, @CGUID+3997, 13, 1, 27746, 249676, 3, 3, 2, 0, 0, 0, 0, 0, ''),
(1581499052891, @CGUID+3997, 14, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1581499053437, @CGUID+3997, 15, 1, 27746, 249676, 3, 3, 2, 0, 0, 0, 0, 0, ''),
(1581499054078, @CGUID+3997, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(1581499063031, @CGUID+3997, 17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');

INSERT INTO `creature_values_update` (`unixtimems`, `guid`, `entry`, `scale`, `display_id`, `mount_display_id`, `faction`, `level`, `npc_flags`, `unit_flags`, `unit_flags2`, `dynamic_flags`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `channel_spell_id`, `channel_visual_id`) VALUES
(1581499031391, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 33687552, NULL, NULL, NULL, NULL, NULL, NULL, 4194304, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499032297, @CGUID+3997, NULL, NULL, NULL, NULL, 6, NULL, NULL, 50462728, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499040812, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499041219, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 100, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499041562, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499042422, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 80, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499042828, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 70, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499043234, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499043578, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499044453, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499044859, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 30, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499045281, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499045672, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499046875, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499050922, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499052141, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499052531, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499053750, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499056984, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499062625, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499063453, @CGUID+3997, NULL, NULL, NULL, NULL, 1616, NULL, NULL, 33685504, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499063844, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1581499067500, @CGUID+3997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

INSERT INTO `creature_speed_update` (`unixtimems`, `guid`, `speed_type`, `speed_rate`) VALUES
(1581499042125, @CGUID+3997, 1, 1.285714),
(1581499046141, @CGUID+3997, 1, 0.8571429),
(1581499050797, @CGUID+3997, 1, 1.285714),
(1581499051734, @CGUID+3997, 1, 0.8571429),
(1581499052141, @CGUID+3997, 1, 1.285714),
(1581499052891, @CGUID+3997, 1, 0.8571429),
(1581499053437, @CGUID+3997, 1, 1.285714),
(1581499054078, @CGUID+3997, 1, 0.8571429);

INSERT INTO `creature_movement_client` (`unixtimems`, `guid`, `opcode`, `move_time`, `move_flags`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1581499032297, @CGUID+3997, 'CMSG_MOVE_SPLINE_DONE', 416390916, 2048, 1, -1524.387, 159.8109, -7.789179, 0.2962068),
(1581499034172, @CGUID+3997, 'CMSG_MOVE_START_STRAFE_LEFT', 416392792, 4, 1, -1524.387, 159.8109, -7.789179, 0.2962068),
(1581499034484, @CGUID+3997, 'CMSG_MOVE_SET_FACING', 416393105, 4, 1, -1524.893, 161.6189, -7.790655, 0.186251),
(1581499034687, @CGUID+3997, 'CMSG_MOVE_SET_FACING', 416393313, 4, 1, -1524.886, 162.8595, -7.792163, 6.170985),
(1581499035187, @CGUID+3997, 'CMSG_MOVE_HEARTBEAT', 416393813, 4, 1, -1524.55, 165.8406, -7.792163, 6.170985),
(1581499035484, @CGUID+3997, 'CMSG_MOVE_STOP_STRAFE', 416394111, 0, 1, -1524.35, 167.6174, -7.792163, 6.170985),
(1581499035625, @CGUID+3997, 'CMSG_MOVE_START_FORWARD', 416394249, 1, 1, -1524.35, 167.6174, -7.792163, 6.170985),
(1581499035750, @CGUID+3997, 'CMSG_MOVE_STOP', 416394383, 0, 1, -1523.551, 167.5273, -7.792163, 6.170985),
(1581499042125, @CGUID+3997, 'CMSG_MOVE_FORCE_RUN_SPEED_CHANGE_ACK', 416400752, 0, 1, -1523.551, 167.5273, -7.792163, 6.170985),
(1581499046156, @CGUID+3997, 'CMSG_MOVE_FORCE_RUN_SPEED_CHANGE_ACK', 416404776, 0, 1, -1523.551, 167.5273, -7.792163, 6.170985),
(1581499050797, @CGUID+3997, 'CMSG_MOVE_FORCE_RUN_SPEED_CHANGE_ACK', 416409429, 0, 1, -1523.551, 167.5273, -7.792163, 6.170985),
(1581499051734, @CGUID+3997, 'CMSG_MOVE_FORCE_RUN_SPEED_CHANGE_ACK', 416410359, 0, 1, -1523.551, 167.5273, -7.792163, 6.170985),
(1581499052141, @CGUID+3997, 'CMSG_MOVE_FORCE_RUN_SPEED_CHANGE_ACK', 416410762, 0, 1, -1523.551, 167.5273, -7.792163, 6.170985),
(1581499052891, @CGUID+3997, 'CMSG_MOVE_FORCE_RUN_SPEED_CHANGE_ACK', 416411519, 0, 1, -1523.551, 167.5273, -7.792163, 6.170985),
(1581499053453, @CGUID+3997, 'CMSG_MOVE_FORCE_RUN_SPEED_CHANGE_ACK', 416412074, 0, 1, -1523.551, 167.5273, -7.792163, 6.170985),
(1581499054078, @CGUID+3997, 'CMSG_MOVE_FORCE_RUN_SPEED_CHANGE_ACK', 416412709, 0, 1, -1523.551, 167.5273, -7.792163, 6.170985);

INSERT INTO `creature_movement_server` (`unixtimems`, `guid`, `point`, `move_time`, `spline_flags`, `spline_count`, `start_position_x`, `start_position_y`, `start_position_z`, `end_position_x`, `end_position_y`, `end_position_z`, `orientation`) VALUES
(1581499029844, @CGUID+3981, 1, 3694, 2432696320, 1, -1529.96, 90.95863, 0.8644979, -1520.834, 91.66602, 1.801932, 100), -- 3035
(1581499033516, @CGUID+3981, 2, 11609, 2432696320, 1, -1520.923, 91.65968, 1.806742, -1543.633, 108.6494, -3.754445, 100), -- 3035
(1581499044453, @CGUID+3981, 3, 0, 0, 0, -1542.31, 107.6739, -3.395543, 0, 0, 0, 100), -- 3035
(1581499054078, @CGUID+3981, 4, 9157, 2432696320, 1, -1542.31, 107.6739, -3.395543, -1526.966, 91.43347, 1.072928, 100), -- 3035
(1581499062625, @CGUID+3981, 5, 0, 0, 0, -1528.079, 92.63375, 0.8785925, 0, 0, 0, 100), -- 3035
(1581499066266, @CGUID+3981, 6, 8541, 2432696320, 1, -1528.079, 92.63375, 0.8785925, -1540.086, 109.6352, -3.396412, 100), -- 3035
(1581499035141, @CGUID+3986, 1, 2474, 2432696320, 1, -1482.171, 116.187, 0.8502517, -1482.197, 112.1908, 1.906284, 100), -- 2957
(1581499037984, @CGUID+3986, 2, 10606, 2432696320, 1, -1482.197, 112.1908, 1.906284, -1465.152, 116.7051, 2.462742, 100), -- 2957
(1581499058203, @CGUID+3986, 3, 7756, 2432696320, 1, -1465.152, 116.7051, 2.462742, -1477.924, 116.4395, 1.15958, 100), -- 2957
(1581499065875, @CGUID+3986, 4, 5725, 2432696320, 1, -1477.789, 116.4417, 1.189835, -1486.959, 118.6855, 0.251987, 100), -- 2957
(1581499028234, @CGUID+3985, 1, 3318, 2432696320, 1, -1580.981, 162.978, -7.586687, -1582.834, 154.9001, -7.711545, 100), -- 14849
(1581499030672, @CGUID+3985, 2, 3886, 2432696320, 1, -1582.386, 157.0788, -7.662169, -1580.278, 147.8651, -7.461545, 100), -- 14849
(1581499033109, @CGUID+3985, 3, 3852, 2432696320, 1, -1581.437, 151.0609, -7.565588, -1574.981, 144.6046, -7.711545, 100), -- 14849
(1581499035531, @CGUID+3985, 4, 5508, 2432696320, 1, -1578.159, 146.5607, -7.561557, -1568.012, 137.3866, -7.662594, 100), -- 14849
(1581499040391, @CGUID+3985, 5, 3232, 2432696320, 1, -1569.139, 138.5538, -7.67051, -1561.757, 138.9751, -7.682179, 100), -- 14849
(1581499042828, @CGUID+3985, 6, 3856, 2432696320, 1, -1563.768, 138.4643, -7.675881, -1555.955, 143.8228, -7.682179, 100), -- 14849
(1581499045281, @CGUID+3985, 7, 4617, 2432696320, 1, -1558.688, 141.5394, -7.682179, -1549.952, 149.0791, -7.682179, 100), -- 14849
(1581499048906, @CGUID+3985, 8, 4560, 2432696320, 1, -1551.812, 147.4506, -7.682179, -1541.781, 152.6723, -7.682179, 100), -- 14849
(1581499052531, @CGUID+3985, 9, 4788, 2432696320, 1, -1543.909, 151.7363, -7.682179, -1532.929, 156.4973, -7.667809, 100), -- 14849
(1581499056156, @CGUID+3985, 10, 3957, 2432696320, 1, -1535.602, 155.3422, -7.672148, -1527.361, 160.7054, -7.667809, 100), -- 14849
(1581499058594, @CGUID+3985, 11, 4532, 2432696320, 1, -1530.404, 158.4056, -7.667809, -1521.643, 165.5794, -7.667809, 100), -- 14849
(1581499062234, @CGUID+3985, 12, 7487, 2432696320, 1, -1523.345, 164.1281, -7.667809, -1507.18, 173.4796, -7.694668, 100), -- 14849
(1581499068297, @CGUID+3985, 13, 6201, 2432696320, 1, -1510.317, 171.7661, -7.688842, -1496.735, 179.2351, -7.667808, 100), -- 14849
(1581499047281, @CGUID+3982, 1, 1651, 2432696320, 1, -1574.779, 137.5245, -7.711545, -1575.337, 135.0884, -7.813473, 100), -- 14827
(1581499048500, @CGUID+3982, 2, 1655, 2432696320, 1, -1575.188, 135.7423, -7.786123, -1576.071, 132.1938, -8.011875, 100), -- 14827
(1581499049703, @CGUID+3982, 3, 1652, 2432696320, 1, -1575.836, 133.1423, -7.868075, -1575.639, 128.7509, -8.138584, 100), -- 14827
(1581499050922, @CGUID+3982, 4, 1650, 2432696320, 1, -1575.691, 129.9124, -8.137164, -1577.42, 126.312, -8.644688, 100), -- 14827
(1581499052141, @CGUID+3982, 5, 1663, 2432696320, 1, -1576.953, 127.285, -8.504972, -1579.152, 123.938, -8.88773, 100), -- 14827
(1581499053344, @CGUID+3982, 6, 1652, 2432696320, 1, -1578.538, 124.8712, -8.872844, -1580.892, 121.5685, -9.525181, 100), -- 14827
(1581499054547, @CGUID+3982, 7, 1669, 2432696320, 1, -1580.245, 122.4728, -9.373043, -1581.365, 117.3764, -9.741123, 100), -- 14827
(1581499055750, @CGUID+3982, 8, 1684, 2432696320, 1, -1581.079, 118.6857, -9.74661, -1584.199, 116.7018, -10.77823, 100), -- 14827
(1581499056984, @CGUID+3982, 9, 1649, 2432696320, 1, -1583.349, 117.2414, -10.43405, -1587.07, 114.6138, -11.42691, 100), -- 14827
(1581499058203, @CGUID+3982, 10, 1665, 2432696320, 1, -1586.077, 115.3176, -11.22196, -1589.894, 115.2793, -12.33243, 100), -- 14827
(1581499059406, @CGUID+3982, 11, 1653, 2432696320, 1, -1588.875, 115.291, -11.96166, -1592.769, 115.9547, -13.00357, 100), -- 14827
(1581499060625, @CGUID+3982, 12, 1641, 2432696320, 1, -1591.708, 115.7735, -12.85499, -1595.615, 116.625, -13.76188, 100), -- 14827
(1581499061844, @CGUID+3982, 13, 1652, 2432696320, 1, -1594.588, 116.4011, -13.49242, -1598.477, 117.2957, -14.64615, 100), -- 14827
(1581499063031, @CGUID+3982, 14, 1635, 2432696320, 1, -1597.404, 117.0489, -14.36441, -1601.303, 117.9551, -15.44824, 100), -- 14827
(1581499064250, @CGUID+3982, 15, 1660, 2432696320, 1, -1600.324, 117.7275, -15.07238, -1604.192, 119.1574, -15.9541, 100), -- 14827
(1581499065453, @CGUID+3982, 16, 1661, 2432696320, 1, -1603.112, 118.7588, -15.81545, -1607.181, 119.3212, -16.49158, 100), -- 14827
(1581499066672, @CGUID+3982, 17, 1597, 2432696320, 1, -1606.102, 119.1727, -16.3263, -1610.086, 119.4766, -16.94824, 100), -- 14827
(1581499067906, @CGUID+3982, 18, 1602, 2432696320, 1, -1609.141, 119.4043, -16.82964, -1613.133, 119.6465, -17.32324, 100), -- 14827
(1581499069016, @CGUID+3982, 19, 1652, 2432696320, 1, -1612.129, 119.5856, -17.19746, -1616.585, 121.4934, -17.62573, 100), -- 14827
(1581499070312, @CGUID+3982, 20, 1655, 2432696320, 1, -1615.381, 120.9789, -17.54408, -1619.3, 120.1325, -17.82666, 100), -- 14827
(1581499047281, @CGUID+3983, 1, 3423, 2432696320, 1, -1575.642, 134.2555, -7.913327, -1577.65, 125.9953, -8.710484, 100), -- 14823
(1581499049703, @CGUID+3983, 2, 5721, 2432696320, 1, -1577.038, 128.4024, -8.345541, -1584.471, 116.64, -10.79313, 100), -- 14823
(1581499054547, @CGUID+3983, 3, 3286, 2432696320, 1, -1583.18, 118.416, -10.39457, -1590.06, 115.3175, -12.39725, 100), -- 14823
(1581499056984, @CGUID+3983, 4, 8050, 2432696320, 1, -1588.078, 115.7858, -11.77779, -1607.058, 119.3139, -16.47742, 100), -- 14823
(1581499064250, @CGUID+3983, 5, 5831, 2432696320, 1, -1605.168, 118.8678, -16.23557, -1619.564, 119.9997, -17.8584, 100), -- 14823
(1581499069016, @CGUID+3983, 6, 3098, 2432696320, 1, -1617.134, 119.8665, -17.70425, -1624.306, 117.6227, -17.82324, 100), -- 14823
(1581499034656, @CGUID+3987, 1, 503, 2432696320, 1, -1555.156, 110.3848, -5.490895, -1556.288, 109.8374, -5.425221, 100), -- 14867
(1581499043234, @CGUID+3987, 2, 894, 2432696320, 1, -1556.288, 109.8374, -5.425221, -1557.727, 111.5332, -5.628712, 100), -- 14867
(1581499044453, @CGUID+3987, 3, 1082, 2432696320, 1, -1557.727, 111.5332, -5.628712, -1559.939, 110.0405, -5.449635, 100), -- 14867
(1581499045672, @CGUID+3987, 4, 2293, 2432696320, 1, -1559.939, 110.0405, -5.449635, -1555.371, 106.6391, -4.834279, 100), -- 14867
(1581499046875, @CGUID+3987, 5, 0, 0, 0, -1557.532, 108.2483, -5.098878, 0, 0, 0, 100), -- 14867
(1581499056578, @CGUID+3987, 6, 882, 2432696320, 1, -1557.532, 108.2483, -5.098878, -1559.531, 107.3934, -4.699635, 100), -- 14867
(1581499062625, @CGUID+3987, 7, 1606, 2432696320, 1, -1559.531, 107.3934, -4.699635, -1556.159, 109.4828, -5.382618, 100), -- 14867
(1581499063844, @CGUID+3987, 8, 1191, 2432696320, 1, -1557.013, 108.9543, -5.280324, -1556.59, 106.0735, -4.703053, 100), -- 14867
(1581499065047, @CGUID+3987, 9, 2213, 2432696320, 1, -1556.59, 106.0735, -4.703053, -1555.668, 111.3984, -5.612477, 100), -- 14867
(1581499066266, @CGUID+3987, 10, 372, 2432696320, 1, -1556.091, 108.9626, -5.294841, -1555.164, 109.0244, -5.327443, 100), -- 14867
(1581499067906, @CGUID+3996, 1, 10357, 2432696320, 20, -1612.447, 114.157, -17.49326, -1589.655, 112.0535, -11.56412, 100), -- 14849
(1581499027437, @CGUID+3994, 1, 1650, 2432696320, 1, -1466.356, 188.8066, -7.667799, -1460.883, 200.684, -7.667806, 100), -- 14860
(1581499028641, @CGUID+3994, 2, 1650, 2432696320, 1, -1462.322, 197.5599, -7.667804, -1461.053, 208.7782, -7.667806, 100), -- 14860
(1581499029844, @CGUID+3994, 3, 1651, 2432696320, 1, -1461.392, 205.7801, -7.667804, -1470.02, 212.3175, -7.683188, 100), -- 14860
(1581499031078, @CGUID+3994, 4, 1650, 2432696320, 1, -1467.783, 210.6226, -7.679201, -1479.627, 217.6232, -7.683188, 100), -- 14860
(1581499032297, @CGUID+3994, 5, 1651, 2432696320, 1, -1476.49, 215.7692, -7.683188, -1485.167, 209.9108, -7.683188, 100), -- 14860
(1581499033516, @CGUID+3994, 6, 1650, 2432696320, 1, -1482.897, 211.4438, -7.683188, -1486.718, 200.4584, -7.683188, 100), -- 14860
(1581499034656, @CGUID+3994, 7, 1650, 2432696320, 1, -1485.701, 203.3811, -7.683188, -1490.996, 191.8384, -7.667808, 100), -- 14860
(1581499035937, @CGUID+3994, 8, 1650, 2432696320, 1, -1489.578, 194.9304, -7.671928, -1497.567, 185.0211, -7.667808, 100), -- 14860
(1581499037156, @CGUID+3994, 9, 1651, 2432696320, 1, -1495.495, 187.5914, -7.667808, -1505.675, 179.5859, -7.694668, 100), -- 14860
(1581499038375, @CGUID+3994, 10, 1651, 2432696320, 1, -1502.993, 181.6952, -7.687591, -1514.019, 174.602, -7.694668, 100), -- 14860
(1581499039547, @CGUID+3994, 11, 1651, 2432696320, 1, -1511.1, 176.4795, -7.694668, -1522.432, 169.6542, -7.694668, 100), -- 14860
(1581499040812, @CGUID+3994, 12, 1650, 2432696320, 1, -1519.412, 171.4734, -7.694668, -1532.009, 168.8088, -7.694668, 100), -- 14860
(1581499042016, @CGUID+3994, 13, 1651, 2432696320, 1, -1528.688, 169.5111, -7.694668, -1541.291, 171.2651, -7.728988, 100), -- 14860
(1581499043234, @CGUID+3994, 14, 1651, 2432696320, 1, -1537.909, 170.7946, -7.719779, -1548.833, 168.3615, -7.728988, 100), -- 14860
(1581499044453, @CGUID+3994, 15, 1651, 2432696320, 1, -1545.948, 169.0041, -7.728988, -1556.013, 172.3604, -7.728988, 100), -- 14860
(1581499045672, @CGUID+3994, 16, 1651, 2432696320, 1, -1553.354, 171.474, -7.728988, -1566.478, 171.8479, -7.728988, 100), -- 14860
(1581499046875, @CGUID+3994, 17, 1650, 2432696320, 1, -1562.964, 171.748, -7.728988, -1569.321, 162.6932, -7.711545, 100), -- 14860
(1581499048109, @CGUID+3994, 18, 1651, 2432696320, 1, -1567.645, 165.0804, -7.716143, -1577.488, 156.774, -7.711545, 100), -- 14860
(1581499049312, @CGUID+3994, 19, 1650, 2432696320, 1, -1574.847, 159.0027, -7.711545, -1572.659, 148.6958, -7.711545, 100), -- 14860
(1581499050531, @CGUID+3994, 20, 1651, 2432696320, 1, -1573.244, 151.4503, -7.711545, -1573.258, 138.8192, -7.711545, 100), -- 14860
(1581499051734, @CGUID+3994, 21, 1651, 2432696320, 1, -1573.254, 142.1934, -7.711545, -1574.678, 129.5408, -8.011875, 100), -- 14860
(1581499052891, @CGUID+3994, 22, 1656, 2432696320, 1, -1574.286, 132.9802, -7.895844, -1579.726, 121.4856, -9.146152, 100), -- 14860
(1581499054078, @CGUID+3994, 23, 1663, 2432696320, 1, -1578.229, 124.6474, -8.904791, -1587.292, 116.6727, -11.52396, 100), -- 14860
(1581499055359, @CGUID+3994, 24, 1664, 2432696320, 1, -1584.847, 118.8207, -10.72904, -1595.976, 116.8521, -14.04093, 100), -- 14860
(1581499056578, @CGUID+3994, 25, 1661, 2432696320, 1, -1593.006, 117.3797, -13.29786, -1604.897, 120.0301, -16.12353, 100), -- 14860
(1581499057781, @CGUID+3994, 26, 1658, 2432696320, 1, -1601.727, 119.3149, -15.30578, -1614.508, 120.3302, -17.50171, 100), -- 14860
(1581499059000, @CGUID+3994, 27, 1656, 2432696320, 1, -1611.109, 120.0687, -17.12561, -1622.719, 117.4734, -17.82324, 100), -- 14860
(1581499064250, @CGUID+3994, 28, 1656, 2432696320, 9, -1606.716, 120.4622, -16.27817, -1599.896, 116.8257, -14.98697, 100), -- 14860
(1581499065047, @CGUID+3994, 29, 1668, 2432696320, 1, -1602.299, 118.1072, -15.53372, -1594.987, 109.4871, -11.78617, 100), -- 14860
(1581499066266, @CGUID+3994, 30, 1673, 2432696320, 1, -1596.921, 111.7713, -12.97777, -1593.599, 99.41996, -10.85449, 100), -- 14860
(1581499067500, @CGUID+3994, 31, 1654, 2432696320, 1, -1594.52, 102.8513, -11.00172, -1585.708, 93.80366, -9.588869, 100), -- 14860
(1581499068703, @CGUID+3994, 32, 1652, 2432696320, 1, -1588.109, 96.26092, -9.793846, -1577.935, 87.44326, -9.155519, 100), -- 14860
(1581499069922, @CGUID+3994, 33, 1655, 2432696320, 1, -1580.708, 89.85532, -9.347833, -1569.691, 92.17796, -8.412355, 100), -- 14860
(1581499027437, @CGUID+3995, 1, 2342, 2432696320, 1, -1465.033, 190.3069, -7.667799, -1459.075, 207.9976, -7.667806, 100), -- 14866
(1581499028641, @CGUID+3995, 2, 2570, 2432696320, 1, -1461.235, 199.2565, -7.667799, -1469.814, 212.2356, -7.683188, 100), -- 14866
(1581499029844, @CGUID+3995, 3, 2802, 2432696320, 1, -1459.606, 208.207, -7.668567, -1480.438, 216.4658, -7.683188, 100), -- 14866
(1581499031078, @CGUID+3995, 4, 2620, 2432696320, 1, -1468.704, 211.7975, -7.681598, -1485.209, 209.6578, -7.683188, 100), -- 14866
(1581499032297, @CGUID+3995, 5, 2911, 2432696320, 1, -1477.69, 215.3716, -7.683188, -1487.151, 197.8155, -7.667808, 100), -- 14866
(1581499033516, @CGUID+3995, 6, 3165, 2432696320, 1, -1484.207, 211.0877, -7.683188, -1493.402, 188.0991, -7.667808, 100), -- 14866
(1581499035937, @CGUID+3995, 7, 1939, 2432696320, 1, -1490.148, 193.1575, -7.667808, -1501.037, 182.4568, -7.694668, 100), -- 14866
(1581499037156, @CGUID+3995, 8, 2197, 2432696320, 1, -1496.418, 185.8701, -7.678419, -1511.096, 176.2299, -7.694668, 100), -- 14866
(1581499038375, @CGUID+3995, 9, 2684, 2432696320, 1, -1504.423, 180.3607, -7.694668, -1522.989, 169.6051, -7.694668, 100), -- 14866
(1581499039547, @CGUID+3995, 10, 2916, 2432696320, 1, -1512.72, 175.3253, -7.694668, -1534.508, 168.5881, -7.728988, 100), -- 14866
(1581499040812, @CGUID+3995, 11, 3071, 2432696320, 1, -1521.181, 170.6123, -7.694668, -1544.671, 172.5991, -7.728988, 100), -- 14866
(1581499043234, @CGUID+3995, 12, 2791, 2432696320, 1, -1539.843, 170.6936, -7.728988, -1557.595, 172.0854, -7.728988, 100), -- 14866
(1581499044453, @CGUID+3995, 13, 2769, 2432696320, 1, -1547.797, 169.4165, -7.728988, -1566.934, 170.4624, -7.667809, 100), -- 14866
(1581499045672, @CGUID+3995, 14, 2625, 2432696320, 1, -1555.078, 170.2237, -7.728988, -1569.557, 162.5023, -7.711545, 100), -- 14866
(1581499046875, @CGUID+3995, 15, 2658, 2432696320, 1, -1563.964, 170.9785, -7.687263, -1577.227, 156.3044, -7.711545, 100), -- 14866
(1581499048109, @CGUID+3995, 16, 2628, 2432696320, 1, -1568.987, 164.2322, -7.70204, -1572.692, 148.1498, -7.711545, 100), -- 14866
(1581499049312, @CGUID+3995, 17, 3576, 2432696320, 1, -1575.591, 157.626, -7.711545, -1573.744, 131.0267, -8.011875, 100), -- 14866
(1581499051734, @CGUID+3995, 18, 2880, 2432696320, 1, -1573.161, 140.4114, -7.802177, -1580.924, 119.6035, -9.643833, 100), -- 14866
(1581499052891, @CGUID+3995, 19, 3088, 2432696320, 1, -1573.846, 130.8641, -8.027901, -1590.773, 115.0824, -12.54215, 100), -- 14866
(1581499055359, @CGUID+3995, 20, 2670, 2432696320, 1, -1586.011, 117.2622, -11.24968, -1605.379, 120.0451, -16.18835, 100), -- 14866
(1581499056578, @CGUID+3995, 21, 3299, 2432696320, 1, -1594.732, 116.4288, -13.55665, -1619.991, 120.508, -17.90991, 100), -- 14866
(1581499059000, @CGUID+3995, 22, 2073, 2432696320, 1, -1613.104, 120.2863, -17.28895, -1626.437, 113.3378, -17.82324, 100), -- 14866
(1581499064250, @CGUID+3995, 23, 3393, 2432696320, 17, -1605.262, 122.4646, -15.8727, -1595.75, 112.4663, -12.86478, 100), -- 14866
(1581499065047, @CGUID+3995, 24, 2835, 2432696320, 1, -1600.875, 117.8547, -15.08902, -1592.155, 98.39394, -10.55225, 100), -- 14866
(1581499066266, @CGUID+3995, 25, 3915, 2432696320, 1, -1595.296, 110.6937, -12.42744, -1577.296, 87.81063, -8.997683, 100), -- 14866
(1581499068703, @CGUID+3995, 26, 3370, 2432696320, 1, -1586.957, 94.69293, -9.671446, -1564.785, 94.98942, -5.96494, 100), -- 14866
(1581499063031, @CGUID+3997, 1, 0, 0, 0, -1523.551, 167.5273, -7.792163, 0, 0, 0, 100), -- 15328
(1581499063031, @CGUID+3997, 2, 0, 0, 0, -1523.551, 167.5273, -7.792163, 0, 0, 0, 100), -- 15328
(1581499063031, @CGUID+3997, 3, 0, 0, 0, -1523.551, 167.5273, -7.792163, 0, 0, 0, 100); -- 15328

INSERT INTO `creature_movement_server_spline` (`guid`, `parent_point`, `spline_point`, `position_x`, `position_y`, `position_z`) VALUES
(@CGUID+3996, 1, 1, -1617.541, 112.594, -17.62477), -- 14849
(@CGUID+3996, 1, 2, -1614.385, 113.5625, -17.54328), -- 14849
(@CGUID+3996, 1, 3, -1611.228, 114.5311, -17.46179), -- 14849
(@CGUID+3996, 1, 4, -1609.24, 114.3047, -16.94824), -- 14849
(@CGUID+3996, 1, 5, -1608.246, 114.1914, -16.69824), -- 14849
(@CGUID+3996, 1, 6, -1607.252, 114.0781, -16.32324), -- 14849
(@CGUID+3996, 1, 7, -1605.264, 113.8516, -15.94824), -- 14849
(@CGUID+3996, 1, 8, -1604.27, 113.7383, -15.69824), -- 14849
(@CGUID+3996, 1, 9, -1603.275, 113.625, -15.32324), -- 14849
(@CGUID+3996, 1, 10, -1602.281, 113.5117, -14.82324), -- 14849
(@CGUID+3996, 1, 11, -1601.287, 113.3984, -14.44824), -- 14849
(@CGUID+3996, 1, 12, -1600.293, 113.2852, -14.19824), -- 14849
(@CGUID+3996, 1, 13, -1599.299, 113.1719, -13.88688), -- 14849
(@CGUID+3996, 1, 14, -1597.311, 112.9453, -13.51188), -- 14849
(@CGUID+3996, 1, 15, -1595.322, 112.7188, -13.01188), -- 14849
(@CGUID+3996, 1, 16, -1593.334, 112.4922, -12.38688), -- 14849
(@CGUID+3996, 1, 17, -1591.346, 112.2656, -11.88688), -- 14849
(@CGUID+3996, 1, 18, -1590.352, 112.1523, -11.63688), -- 14849
(@CGUID+3996, 1, 19, -1589.655, 112.0535, -11.56412), -- 14849
(@CGUID+3996, 1, 20, -1589.655, 112.0535, -11.56412), -- 14849
(@CGUID+3994, 28, 1, -1610.725, 122.5996, -16.82324), -- 14860
(@CGUID+3994, 28, 2, -1608.959, 121.6582, -16.57324), -- 14860
(@CGUID+3994, 28, 3, -1607.193, 120.7168, -16.32324), -- 14860
(@CGUID+3994, 28, 4, -1604.545, 119.3047, -16.07324), -- 14860
(@CGUID+3994, 28, 5, -1603.662, 118.834, -15.82324), -- 14860
(@CGUID+3994, 28, 6, -1601.896, 117.8926, -15.44824), -- 14860
(@CGUID+3994, 28, 7, -1601.014, 117.4219, -15.19824), -- 14860
(@CGUID+3994, 28, 8, -1599.896, 116.8257, -14.98697), -- 14860
(@CGUID+3994, 28, 9, -1599.896, 116.8257, -14.98697), -- 14860
(@CGUID+3995, 23, 1, -1616.587, 114.0209, -18.02427), -- 14866
(@CGUID+3995, 23, 2, -1614.832, 115.5104, -17.73625), -- 14866
(@CGUID+3995, 23, 3, -1613.076, 117, -17.44824), -- 14866
(@CGUID+3995, 23, 4, -1610.791, 118.9395, -17.07324), -- 14866
(@CGUID+3995, 23, 5, -1609.268, 120.2324, -16.69824), -- 14866
(@CGUID+3995, 23, 6, -1607.744, 121.5254, -16.44824), -- 14866
(@CGUID+3995, 23, 7, -1606.221, 122.8184, -15.94824), -- 14866
(@CGUID+3995, 23, 8, -1605.874, 123.1085, -15.81225), -- 14866
(@CGUID+3995, 23, 9, -1604.496, 121.6602, -15.94824), -- 14866
(@CGUID+3995, 23, 10, -1603.807, 120.9355, -15.57324), -- 14866
(@CGUID+3995, 23, 11, -1601.738, 118.7617, -15.32324), -- 14866
(@CGUID+3995, 23, 12, -1599.67, 116.5879, -14.76188), -- 14866
(@CGUID+3995, 23, 13, -1598.291, 115.1387, -14.26188), -- 14866
(@CGUID+3995, 23, 14, -1597.602, 114.4141, -13.76188), -- 14866
(@CGUID+3995, 23, 15, -1596.223, 112.9648, -13.26188), -- 14866
(@CGUID+3995, 23, 16, -1595.75, 112.4663, -12.86478), -- 14866
(@CGUID+3995, 23, 17, -1595.75, 112.4663, -12.86478); -- 14866

INSERT INTO `creature_movement_server_combat` (`unixtimems`, `guid`, `point`, `move_time`, `spline_flags`, `spline_count`, `start_position_x`, `start_position_y`, `start_position_z`, `end_position_x`, `end_position_y`, `end_position_z`, `orientation`) VALUES
(1581499026719, @CGUID+3981, 1, 3639, 2432696320, 7, -1522.03, 89.80112, 1.990587, -1529.963, 90.95898, 0.8641882, 100), -- 3035
(1581499026875, @CGUID+3986, 1, 20759, 2432696320, 20, -1492.707, 125.5521, -0.9092584, -1481.609, 115.6635, 0.9418063, 100), -- 2957
(1581499026875, @CGUID+3985, 1, 4713, 2432696320, 5, -1579.879, 166.9071, -7.586904, -1581.699, 160.4157, -7.586545, 100), -- 14849
(1581499027062, @CGUID+3996, 1, 9789, 2432696320, 12, -1604.295, 121.2069, -15.71285, -1626.108, 111.8464, -17.82324, 100), -- 14849
(1581499031391, @CGUID+3997, 1, 0, 0, 0, -1524.387, 159.8109, -7.706064, 0, 0, 0, 0.2962068), -- 15328
(1581499031391, @CGUID+3997, 2, 0, 0, 0, -1524.387, 159.8109, -7.706064, 0, 0, 0, 0.2962068), -- 15328
(1581499031391, @CGUID+3997, 3, 0, 0, 0, -1524.387, 159.8109, -7.706064, 0, 0, 0, 100), -- 15328
(1581499031391, @CGUID+3997, 4, 0, 0, 0, -1524.387, 159.8109, -7.706064, 0, 0, 0, 100); -- 15328

INSERT INTO `creature_movement_server_combat_spline` (`guid`, `parent_point`, `spline_point`, `position_x`, `position_y`, `position_z`) VALUES
(@CGUID+3981, 1, 1, -1519.07, 89.36914, 2.364188), -- 3035
(@CGUID+3981, 1, 2, -1521.051, 89.6582, 2.114188), -- 3035
(@CGUID+3981, 1, 3, -1523.031, 89.94727, 1.864188), -- 3035
(@CGUID+3981, 1, 4, -1525.012, 90.23633, 1.614188), -- 3035
(@CGUID+3981, 1, 5, -1527.982, 90.66992, 1.114188), -- 3035
(@CGUID+3981, 1, 6, -1529.963, 90.95898, 0.8641882), -- 3035
(@CGUID+3981, 1, 7, -1529.963, 90.95898, 0.8641882), -- 3035
(@CGUID+3986, 1, 1, -1508.619, 139.6777, -4.417809), -- 2957
(@CGUID+3986, 1, 2, -1507.123, 138.3496, -4.167809), -- 2957
(@CGUID+3986, 1, 3, -1505.627, 137.0215, -3.917809), -- 2957
(@CGUID+3986, 1, 4, -1504.879, 136.3574, -3.542809), -- 2957
(@CGUID+3986, 1, 5, -1503.383, 135.0293, -3.292809), -- 2957
(@CGUID+3986, 1, 6, -1502.635, 134.3652, -2.917809), -- 2957
(@CGUID+3986, 1, 7, -1501.139, 133.0371, -2.649922), -- 2957
(@CGUID+3986, 1, 8, -1499.643, 131.709, -2.318203), -- 2957
(@CGUID+3986, 1, 9, -1498.895, 131.0449, -2.068203), -- 2957
(@CGUID+3986, 1, 10, -1497.398, 129.7168, -1.818203), -- 2957
(@CGUID+3986, 1, 11, -1496.65, 129.0527, -1.568203), -- 2957
(@CGUID+3986, 1, 12, -1495.154, 127.7246, -1.318203), -- 2957
(@CGUID+3986, 1, 13, -1493.658, 126.3965, -1.068203), -- 2957
(@CGUID+3986, 1, 14, -1491.414, 124.4043, -0.6932034), -- 2957
(@CGUID+3986, 1, 15, -1489.17, 122.4121, -0.3182034), -- 2957
(@CGUID+3986, 1, 16, -1486.926, 120.4199, 0.05679655), -- 2957
(@CGUID+3986, 1, 17, -1484.682, 118.4277, 0.4317966), -- 2957
(@CGUID+3986, 1, 18, -1482.438, 116.4355, 0.8067966), -- 2957
(@CGUID+3986, 1, 19, -1481.609, 115.6635, 0.9418063), -- 2957
(@CGUID+3986, 1, 20, -1481.609, 115.6635, 0.9418063), -- 2957
(@CGUID+3985, 1, 1, -1575.372, 173.7719, -7.682796), -- 14849
(@CGUID+3985, 1, 2, -1577.388, 171.1849, -7.634897), -- 14849
(@CGUID+3985, 1, 3, -1579.405, 168.5978, -7.586998), -- 14849
(@CGUID+3985, 1, 4, -1581.699, 160.4157, -7.586545), -- 14849
(@CGUID+3985, 1, 5, -1581.699, 160.4157, -7.586545), -- 14849
(@CGUID+3996, 1, 1, -1603.669, 121.1676, -15.47746), -- 14849
(@CGUID+3996, 1, 2, -1604.295, 121.2069, -15.71285), -- 14849
(@CGUID+3996, 1, 3, -1604.922, 121.2461, -15.94824), -- 14849
(@CGUID+3996, 1, 4, -1606.918, 121.3711, -16.32324), -- 14849
(@CGUID+3996, 1, 5, -1608.435, 121.4806, -16.45752), -- 14849
(@CGUID+3996, 1, 6, -1610.193, 120.5234, -16.82324), -- 14849
(@CGUID+3996, 1, 7, -1611.072, 120.0449, -17.07324), -- 14849
(@CGUID+3996, 1, 8, -1612.83, 119.0879, -17.32324), -- 14849
(@CGUID+3996, 1, 9, -1614.588, 118.1309, -17.57324), -- 14849
(@CGUID+3996, 1, 10, -1618.104, 116.2168, -17.82324), -- 14849
(@CGUID+3996, 1, 11, -1626.108, 111.8464, -17.82324), -- 14849
(@CGUID+3996, 1, 12, -1626.108, 111.8464, -17.82324); -- 14849

INSERT INTO `creature_guid_values_update` (`unixtimems`, `guid`, `field_name`, `object_guid`, `object_id`, `object_type`) VALUES
(1581499032297, @CGUID+3997, 'CharmedBy', @PGUID+1882, 0, 'Player'),
(1581499063453, @CGUID+3997, 'CharmedBy', 0, 0, '');


DELETE FROM `gameobject` WHERE `guid` BETWEEN @OGUID+0 AND @OGUID+5957;
INSERT INTO `gameobject` (`guid`, `id`, `map`, `zone_id`, `area_id`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `is_temporary`, `creator_guid`, `creator_id`, `creator_type`, `display_id`, `level`, `faction`, `flags`, `dynamic_flags`, `path_progress`, `state`, `type`, `artkit`, `custom_param`, `sniff_build`) VALUES
(@OGUID+5852, 180035, 1, 215, 215, -1533.2, 177.577, -6.357721, 2.565632, 0, 0, 0.9588194, 0.2840165, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5864, 180035, 1, 215, 215, -1550.316, 186.7826, -5.6364, 5.881761, 0, 0, -0.1993675, 0.9799248, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5862, 180043, 1, 215, 215, -1561.083, 133.6458, -7.792809, 2.565632, 0, 0, 0.9588194, 0.2840165, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5846, 179965, 1, 215, 215, -1542.883, 146.4461, -7.634234, 2.373644, 0, 0, 0.9271832, 0.3746083, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5860, 180035, 1, 215, 215, -1549.971, 128.2834, -5.177537, 0.8203033, 0, 0, 0.3987484, 0.9170604, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5851, 180043, 1, 215, 215, -1539.416, 175.9483, -7.740874, 5.567601, 0, 0, -0.3502073, 0.9366722, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5856, 180524, 1, 215, 215, -1507.46, 166.6145, -7.792803, 2.844883, 0, 0, 0.9890156, 0.1478114, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5859, 180335, 1, 215, 215, -1563.926, 157.0875, -7.792809, 0.05235888, 0, 0, 0.02617645, 0.9996573, 0, 0, 0, '', 3972, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5869, 180043, 1, 215, 215, -1570.364, 178.3495, -7.792809, 3.38594, 0, 0, -0.9925461, 0.12187, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5861, 179965, 1, 215, 215, -1557.564, 131.6857, -7.667559, 2.164206, 0, 0, 0.882947, 0.4694727, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5868, 180524, 1, 215, 215, -1560.913, 185.9989, -7.641031, 4.921829, 0, 0, -0.6293201, 0.7771462, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5854, 180042, 1, 215, 215, -1552.203, 140.262, -7.788158, 3.001947, 0, 0, 0.9975634, 0.06976615, 0, 0, 0, '', 6149, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5850, 180006, 1, 215, 215, -1537.301, 175.9692, -7.795676, 3.926996, 0, 0, -0.9238787, 0.3826855, 0, 0, 0, '', 3332, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5863, 180043, 1, 215, 215, -1567.969, 156.1406, -7.792809, 4.049168, 0, 0, -0.8987932, 0.4383728, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5845, 180524, 1, 215, 215, -1523.319, 160.9614, -7.792804, 3.246347, 0, 0, -0.9986286, 0.05235322, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5866, 180034, 1, 215, 215, -1562.363, 126.5048, -6.937747, 3.438303, 0, 0, -0.9890156, 0.1478114, 0, 0, 0, '', 6142, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5865, 180524, 1, 215, 215, -1512.168, 186.9263, -7.792805, 5.724681, 0, 0, -0.2756367, 0.9612619, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5843, 180035, 1, 215, 215, -1523.17, 157.026, -6.465088, 1.291542, 0, 0, 0.6018143, 0.7986361, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5855, 180035, 1, 215, 215, -1509.04, 162.974, -6.50808, 3.176533, 0, 0, -0.9998474, 0.01746928, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5849, 180524, 1, 215, 215, -1532.768, 173.6499, -7.792809, 4.34587, 0, 0, -0.8241262, 0.5664061, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5847, 180035, 1, 215, 215, -1535.44, 141.637, -5.476431, 3.839725, 0, 0, -0.9396925, 0.3420205, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5858, 180044, 1, 215, 215, -1562.326, 158.3941, -8.709473, 3.228859, 0, 0, -0.9990482, 0.04361926, 0, 0, 0, '', 6152, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5848, 180043, 1, 215, 215, -1548.433, 147.6362, -7.786231, 4.642576, 0, 0, -0.7313538, 0.6819983, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5867, 180035, 1, 215, 215, -1491.004, 163.8917, -6.479908, 0.087266, 0, 0, 0.04361916, 0.9990482, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5853, 180006, 1, 215, 215, -1540.204, 177.8263, -7.714711, 4.363324, 0, 0, -0.8191519, 0.5735767, 0, 0, 0, '', 3332, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5857, 180035, 1, 215, 215, -1520.267, 180.4444, -6.371035, 0.7853968, 0, 0, 0.3826828, 0.9238798, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5844, 180524, 1, 215, 215, -1538.857, 146.2337, -7.424007, 2.076939, 0, 0, 0.8616285, 0.5075394, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5883, 179965, 1, 215, 215, -1583.453, 173.2561, -7.774609, 5.672322, 0, 0, -0.300705, 0.9537172, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5886, 180043, 1, 215, 215, -1587.49, 155.2829, -7.650669, 2.722713, 0, 0, 0.9781475, 0.2079121, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5896, 180035, 1, 215, 215, -1472.877, 165.7049, -6.406475, 0.1745321, 0, 0, 0.08715534, 0.9961947, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5899, 180035, 1, 215, 215, -1590.289, 179.8696, -4.564963, 0.8726639, 0, 0, 0.4226179, 0.9063079, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5888, 179973, 1, 215, 215, -1587.571, 158.4834, -7.476216, 0.2617982, 0, 0, 0.1305256, 0.9914449, 0, 0, 0, '', 6036, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5875, 180032, 1, 215, 215, -1577.937, 178.5484, -6.160864, 3.001947, 0, 0, 0.9975634, 0.06976615, 0, 0, 0, '', 6141, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5890, 179972, 1, 215, 215, -1589.354, 158.8736, -7.29741, 6.056293, 0, 0, -0.113203, 0.9935719, 0, 0, 0, '', 31, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5892, 180524, 1, 215, 215, -1479.694, 178.9787, -7.792805, 1.675514, 0, 0, 0.743144, 0.6691315, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5877, 180043, 1, 215, 215, -1585.002, 148.2959, -7.402199, 5.009095, 0, 0, -0.5948229, 0.8038568, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5891, 179965, 1, 215, 215, -1589.511, 157.2613, -7.385764, 6.0912, 0, 0, -0.09584522, 0.9953963, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5885, 180524, 1, 215, 215, -1572.922, 117.8846, -7.751456, 1.797689, 0, 0, 0.782608, 0.6225148, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5872, 180035, 1, 215, 215, -1562.991, 118.8778, -5.581712, 3.508117, 0, 0, -0.9832544, 0.182238, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5870, 179965, 1, 215, 215, -1569.271, 180.0657, -7.792809, 4.834563, 0, 0, -0.6626196, 0.7489561, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5876, 180043, 1, 215, 215, -1581.153, 171.4848, -7.792809, 0.8552105, 0, 0, 0.4146929, 0.9099615, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5879, 179965, 1, 215, 215, -1570.374, 117.3299, -7.319073, 3.926996, 0, 0, -0.9238787, 0.3826855, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5901, 180035, 1, 215, 215, -1597.858, 162.7604, -5.153922, 1.623156, 0, 0, 0.7253742, 0.6883547, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5882, 180029, 1, 215, 215, -1579.956, 128.6112, -8.390238, 3.944446, 0, 0, -0.9205046, 0.3907318, 0, 0, 0, '', 6137, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5880, 179965, 1, 215, 215, -1585.375, 144.9552, -7.087506, 0.5410506, 0, 0, 0.2672377, 0.9636307, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5902, 180035, 1, 215, 215, -1499.774, 215.5764, -5.284359, 0.9599299, 0, 0, 0.4617481, 0.8870111, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5884, 180524, 1, 215, 215, -1584.359, 138.3439, -6.636925, 0.06981169, 0, 0, 0.03489876, 0.9993908, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5881, 179970, 1, 215, 215, -1586.227, 158.3426, -7.550742, 5.619962, 0, 0, -0.3255672, 0.9455189, 0, 0, 0, '', 286, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5871, 180043, 1, 215, 215, -1568.991, 128.8486, -7.806101, 5.462882, 0, 0, -0.3987484, 0.9170604, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5873, 180035, 1, 215, 215, -1509.95, 196.9149, -6.351888, 1.169369, 0, 0, 0.5519361, 0.8338864, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5893, 179965, 1, 215, 215, -1585.372, 130.1515, -7.714327, 4.136433, 0, 0, -0.8788166, 0.4771597, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5903, 180049, 1, 215, 215, -1476.648, 196.7795, -7.285858, 3.700105, 0, 0, -0.9612608, 0.2756405, 0, 0, 0, '', 3151, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5900, 180045, 1, 215, 215, -1480.695, 194.7397, -7.792803, 5.288348, 0, 0, -0.4771585, 0.8788173, 0, 0, 0, '', 5392, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5874, 180036, 1, 215, 215, -1487.545, 172.3976, -5.438641, 0.122173, 0, 0, 0.06104851, 0.9981348, 0, 0, 0, '', 6144, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5905, 179965, 1, 215, 215, -1463.662, 168.5868, -7.74115, 5.305802, 0, 0, -0.469471, 0.8829479, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5887, 2912, 1, 215, 215, -1532.64, 209.9104, -7.928488, 2.024579, 0, 0, 0.8480473, 0.5299206, 0, 0, 0, '', 424, 0, 0, 4, 0, 65535, 1, 3, 0, 0, 33155),
(@OGUID+5894, 180031, 1, 215, 215, -1589.899, 164.8819, -6.098957, 3.228859, 0, 0, -0.9990482, 0.04361926, 0, 0, 0, '', 6139, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5889, 179967, 1, 215, 215, -1589.263, 158.8458, -6.063687, 2.268925, 0, 0, 0.9063072, 0.4226195, 0, 0, 0, '', 32, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5907, 180524, 1, 215, 215, -1487.805, 208.9352, -7.792101, 5.619962, 0, 0, -0.3255672, 0.9455189, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5904, 180047, 1, 215, 215, -1476.575, 196.8444, -7.792803, 0.6632232, 0, 0, 0.3255672, 0.9455189, 0, 0, 0, '', 138, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5895, 180030, 1, 215, 215, -1591.423, 148.4819, -6.801592, 3.089183, 0, 0, 0.9996567, 0.02620165, 0, 0, 0, '', 6138, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5878, 180035, 1, 215, 215, -1571.76, 190.1771, -5.015974, 3.228859, 0, 0, -0.9990482, 0.04361926, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5897, 180036, 1, 215, 215, -1496.323, 203.4045, -5.430457, 1.012289, 0, 0, 0.4848089, 0.8746201, 0, 0, 0, '', 6144, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5898, 180040, 1, 215, 215, -1617.413, 107.0941, -17.94824, 1.047198, 0, 0, 0.5, 0.8660254, 0, 0, 0, '', 1787, 0, 114, 0, 0, 65535, 1, 0, 0, 0, 33155),
(@OGUID+5906, 180046, 1, 215, 215, -1477.01, 197.7799, -7.792803, 0.4363316, 0, 0, 0.2164392, 0.9762961, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, 33155),
(@OGUID+5929, 180524, 1, 215, 215, -1616.081, 127.7134, -17.57194, 5.393069, 0, 0, -0.4305105, 0.9025856, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5938, 180035, 1, 215, 215, -1618.089, 100.5399, -16.89963, 5.253442, 0, 0, -0.4924231, 0.870356, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5918, 180047, 1, 215, 215, -1475.056, 201.6655, -7.792803, 4.572764, 0, 0, -0.7547092, 0.6560594, 0, 0, 0, '', 138, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5910, 180053, 1, 215, 215, -1474.754, 198.7691, -7.917803, 1.221729, 0, 0, 0.573576, 0.8191524, 0, 0, 0, '', 197, 0, 0, 0, 0, 65535, 1, 8, 0, 0, 33155),
(@OGUID+5915, 179965, 1, 215, 215, -1582.292, 100.9226, -9.762853, 4.97419, 0, 0, -0.6087608, 0.7933538, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5942, 179965, 1, 215, 215, -1444.971, 214.8166, -7.75072, 0.3141584, 0, 0, 0.1564341, 0.9876884, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5956, 179965, 1, 215, 215, -1308.958, 70.70155, 128.8397, 5.672322, 0, 0, -0.300705, 0.9537172, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5925, 180043, 1, 215, 215, -1611.672, 125.5455, -16.66829, 5.096362, 0, 0, -0.5591927, 0.8290377, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5953, 180035, 1, 215, 215, -1636.687, 88.18826, -16.43352, 5.026549, 0, 0, -0.5877848, 0.8090174, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5952, 180035, 1, 215, 215, -1642.39, 101.0805, -16.4149, 2.303831, 0, 0, 0.9135447, 0.4067384, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5943, 180035, 1, 215, 215, -1449.432, 222.3142, -6.395928, 5.410522, 0, 0, -0.4226179, 0.9063079, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5924, 179965, 1, 215, 215, -1493.464, 223.9403, -6.37694, 2.356195, 0, 0, 0.9238796, 0.3826832, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5934, 180524, 1, 215, 215, -1613.565, 106.5597, -17.72129, 1.361356, 0, 0, 0.6293201, 0.7771462, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5923, 180035, 1, 215, 215, -1455.819, 174.3352, -6.423319, 4.01426, 0, 0, -0.9063072, 0.4226195, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5936, 180035, 1, 215, 215, -1625.418, 127.5017, -16.62185, 0.06981169, 0, 0, 0.03489876, 0.9993908, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5947, 179965, 1, 215, 215, -1638.014, 116.6697, -17.89151, 5.532695, 0, 0, -0.3665009, 0.9304177, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5922, 180045, 1, 215, 215, -1475.002, 206.0911, -7.792804, 3.071766, 0, 0, 0.9993906, 0.03490613, 0, 0, 0, '', 5392, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5944, 180035, 1, 215, 215, -1617.045, 87.51644, -16.6288, 4.32842, 0, 0, -0.8290367, 0.5591941, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5940, 180035, 1, 215, 215, -1466.377, 232.9705, -6.379005, 6.056293, 0, 0, -0.113203, 0.9935719, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5928, 180524, 1, 215, 215, -1477.186, 221.6333, -7.746772, 4.625124, 0, 0, -0.737277, 0.6755905, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5914, 180048, 1, 215, 215, -1472.379, 196.724, -7.292803, 2.600535, 0, 0, 0.9636297, 0.267241, 0, 0, 0, '', 3091, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5946, 179965, 1, 215, 215, -1618.758, 86.84432, -17.94824, 5.829401, 0, 0, -0.2249508, 0.9743701, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5955, 179965, 1, 215, 215, -1324.485, 83.88734, 129.707, 0.3490652, 0, 0, 0.1736479, 0.9848078, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5931, 180524, 1, 215, 215, -1455.809, 201.5383, -7.790167, 2.844883, 0, 0, 0.9890156, 0.1478114, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5935, 180524, 1, 215, 215, -1458.394, 214.3719, -7.792798, 4.450591, 0, 0, -0.7933531, 0.6087617, 0, 0, 0, '', 6424, 0, 35, 0, 0, 65535, 1, 1, 0, 0, 33155),
(@OGUID+5932, 180035, 1, 215, 215, -1446.113, 189.2778, -6.070208, 4.34587, 0, 0, -0.8241262, 0.5664061, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5919, 180048, 1, 215, 215, -1474.985, 201.7063, -7.285859, 0.6632232, 0, 0, 0.3255672, 0.9455189, 0, 0, 0, '', 3091, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5909, 181029, 1, 215, 215, -1474.754, 198.7691, -7.917803, 1.221729, 0, 0, 0.573576, 0.8191524, 0, 0, 0, '', 6624, 1, 14, 0, 0, 65535, 1, 6, 0, 0, 33155),
(@OGUID+5908, 180043, 1, 215, 215, -1595.106, 122.6291, -12.66304, 4.293513, 0, 0, -0.8386698, 0.5446402, 0, 0, 0, '', 4094, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5926, 180036, 1, 215, 215, -1455.318, 191.7431, -5.450096, 1.117009, 0, 0, 0.5299187, 0.8480484, 0, 0, 0, '', 6144, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5950, 179965, 1, 215, 215, -1641.018, 103.7275, -17.94824, 3.804818, 0, 0, -0.9455185, 0.3255684, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5949, 180035, 1, 215, 215, -1644.406, 112.6974, -15.91671, 4.118979, 0, 0, -0.882947, 0.4694727, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5920, 180046, 1, 215, 215, -1474.173, 201.1931, -7.792803, 4.520403, 0, 0, -0.7716246, 0.6360782, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, 33155),
(@OGUID+5941, 179965, 1, 215, 215, -1629.676, 122.1466, -17.94824, 4.956738, 0, 0, -0.6156607, 0.7880114, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5927, 179965, 1, 215, 215, -1597.148, 98.94523, -11.76186, 5.009095, 0, 0, -0.5948229, 0.8038568, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5916, 180049, 1, 215, 215, -1475.233, 201.5885, -7.278914, 5.340709, 0, 0, -0.45399, 0.8910068, 0, 0, 0, '', 3151, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5951, 180035, 1, 215, 215, -1627.107, 80.43978, -16.52463, 3.194002, 0, 0, -0.9996567, 0.02620165, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5911, 1618, 1, 215, 215, -1598.672, 184.7273, -3.619153, 4.502952, 0, 0, -0.7771454, 0.6293211, 0, 0, 0, '', 269, 0, 0, 0, 0, 65535, 1, 3, 0, 0, 33155),
(@OGUID+5913, 180047, 1, 215, 215, -1472.435, 196.713, -7.792803, 2.722713, 0, 0, 0.9781475, 0.2079121, 0, 0, 0, '', 138, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5957, 179965, 1, 215, 215, -1298.268, 104.9622, 131.2188, 0.3316107, 0, 0, 0.1650467, 0.9862857, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5930, 180035, 1, 215, 215, -1485.802, 231.1441, -5.233857, 0.6457717, 0, 0, 0.3173046, 0.9483237, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5954, 179965, 1, 215, 215, -1326.533, 89.46688, 129.8198, 0.3665176, 0, 0, 0.1822348, 0.983255, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5917, 180046, 1, 215, 215, -1472.15, 197.6841, -7.792803, 2.722713, 0, 0, 0.9781475, 0.2079121, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, 33155),
(@OGUID+5939, 180035, 1, 215, 215, -1444.139, 206.059, -6.207995, 4.834563, 0, 0, -0.6626196, 0.7489561, 0, 0, 0, '', 6157, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5921, 180045, 1, 215, 215, -1468.202, 195.7496, -7.792795, 1.134463, 0, 0, 0.5372992, 0.8433917, 0, 0, 0, '', 5392, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5912, 180046, 1, 215, 215, -1475.913, 201.1984, -7.792803, 4.956738, 0, 0, -0.6156607, 0.7880114, 0, 0, 0, '', 39, 0, 0, 0, 0, 65535, 1, 7, 0, 0, 33155),
(@OGUID+5933, 180036, 1, 215, 215, -1464.705, 221.2604, -5.258084, 5.951575, 0, 0, -0.1650467, 0.9862857, 0, 0, 0, '', 6144, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5937, 180037, 1, 215, 215, -1626.319, 122.4444, -17.61427, 3.036838, 0, 0, 0.9986286, 0.05235322, 0, 0, 0, '', 6145, 0, 0, 0, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5945, 180039, 1, 215, 215, -1636.011, 120.0071, -17.42741, 3.176533, 0, 0, -0.9998474, 0.01746928, 0, 0, 0, '', 6147, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155),
(@OGUID+5948, 179965, 1, 215, 215, -1626.451, 83.56036, -17.94824, 4.677484, 0, 0, -0.7193394, 0.6946588, 0, 0, 0, '', 6091, 0, 0, 32, 0, 65535, 1, 5, 0, 0, 33155);

INSERT INTO `gameobject_create1_time` (`unixtimems`, `guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1581499026719, @OGUID+5852, 1, -1533.2, 177.577, -6.357721, 2.565632),
(1581499026719, @OGUID+5864, 1, -1550.316, 186.7826, -5.6364, 5.881761),
(1581499026719, @OGUID+5862, 1, -1561.083, 133.6458, -7.792809, 2.565632),
(1581499026719, @OGUID+5846, 1, -1542.883, 146.4461, -7.634234, 2.373644),
(1581499026719, @OGUID+5860, 1, -1549.971, 128.2834, -5.177537, 0.8203033),
(1581499026719, @OGUID+5851, 1, -1539.416, 175.9483, -7.740874, 5.567601),
(1581499026719, @OGUID+5856, 1, -1507.46, 166.6145, -7.792803, 2.844883),
(1581499026719, @OGUID+5859, 1, -1563.926, 157.0875, -7.792809, 0.05235888),
(1581499026719, @OGUID+5869, 1, -1570.364, 178.3495, -7.792809, 3.38594),
(1581499026719, @OGUID+5861, 1, -1557.564, 131.6857, -7.667559, 2.164206),
(1581499026719, @OGUID+5868, 1, -1560.913, 185.9989, -7.641031, 4.921829),
(1581499026719, @OGUID+5854, 1, -1552.203, 140.262, -7.788158, 3.001947),
(1581499026719, @OGUID+5850, 1, -1537.301, 175.9692, -7.795676, 3.926996),
(1581499026719, @OGUID+5863, 1, -1567.969, 156.1406, -7.792809, 4.049168),
(1581499026719, @OGUID+5845, 1, -1523.319, 160.9614, -7.792804, 3.246347),
(1581499026719, @OGUID+5866, 1, -1562.363, 126.5048, -6.937747, 3.438303),
(1581499026719, @OGUID+5865, 1, -1512.168, 186.9263, -7.792805, 5.724681),
(1581499026719, @OGUID+5843, 1, -1523.17, 157.026, -6.465088, 1.291542),
(1581499026719, @OGUID+5855, 1, -1509.04, 162.974, -6.50808, 3.176533),
(1581499026719, @OGUID+5849, 1, -1532.768, 173.6499, -7.792809, 4.34587),
(1581499026719, @OGUID+5847, 1, -1535.44, 141.637, -5.476431, 3.839725),
(1581499026719, @OGUID+5858, 1, -1562.326, 158.3941, -8.709473, 3.228859),
(1581499026719, @OGUID+5848, 1, -1548.433, 147.6362, -7.786231, 4.642576),
(1581499026719, @OGUID+5867, 1, -1491.004, 163.8917, -6.479908, 0.087266),
(1581499026719, @OGUID+5853, 1, -1540.204, 177.8263, -7.714711, 4.363324),
(1581499026719, @OGUID+5857, 1, -1520.267, 180.4444, -6.371035, 0.7853968),
(1581499026719, @OGUID+5844, 1, -1538.857, 146.2337, -7.424007, 2.076939),
(1581499026875, @OGUID+5883, 1, -1583.453, 173.2561, -7.774609, 5.672322),
(1581499026875, @OGUID+5886, 1, -1587.49, 155.2829, -7.650669, 2.722713),
(1581499026875, @OGUID+5896, 1, -1472.877, 165.7049, -6.406475, 0.1745321),
(1581499026875, @OGUID+5899, 1, -1590.289, 179.8696, -4.564963, 0.8726639),
(1581499026875, @OGUID+5888, 1, -1587.571, 158.4834, -7.476216, 0.2617982),
(1581499026875, @OGUID+5875, 1, -1577.937, 178.5484, -6.160864, 3.001947),
(1581499026875, @OGUID+5890, 1, -1589.354, 158.8736, -7.29741, 6.056293),
(1581499026875, @OGUID+5892, 1, -1479.694, 178.9787, -7.792805, 1.675514),
(1581499026875, @OGUID+5877, 1, -1585.002, 148.2959, -7.402199, 5.009095),
(1581499026875, @OGUID+5891, 1, -1589.511, 157.2613, -7.385764, 6.0912),
(1581499026875, @OGUID+5885, 1, -1572.922, 117.8846, -7.751456, 1.797689),
(1581499026875, @OGUID+5872, 1, -1562.991, 118.8778, -5.581712, 3.508117),
(1581499026875, @OGUID+5870, 1, -1569.271, 180.0657, -7.792809, 4.834563),
(1581499026875, @OGUID+5876, 1, -1581.153, 171.4848, -7.792809, 0.8552105),
(1581499026875, @OGUID+5879, 1, -1570.374, 117.3299, -7.319073, 3.926996),
(1581499026875, @OGUID+5901, 1, -1597.858, 162.7604, -5.153922, 1.623156),
(1581499026875, @OGUID+5882, 1, -1579.956, 128.6112, -8.390238, 3.944446),
(1581499026875, @OGUID+5880, 1, -1585.375, 144.9552, -7.087506, 0.5410506),
(1581499026875, @OGUID+5902, 1, -1499.774, 215.5764, -5.284359, 0.9599299),
(1581499026875, @OGUID+5884, 1, -1584.359, 138.3439, -6.636925, 0.06981169),
(1581499026875, @OGUID+5881, 1, -1586.227, 158.3426, -7.550742, 5.619962),
(1581499026875, @OGUID+5871, 1, -1568.991, 128.8486, -7.806101, 5.462882),
(1581499026875, @OGUID+5873, 1, -1509.95, 196.9149, -6.351888, 1.169369),
(1581499026875, @OGUID+5893, 1, -1585.372, 130.1515, -7.714327, 4.136433),
(1581499026875, @OGUID+5903, 1, -1476.648, 196.7795, -7.285858, 3.700105),
(1581499026875, @OGUID+5900, 1, -1480.695, 194.7397, -7.792803, 5.288348),
(1581499026875, @OGUID+5874, 1, -1487.545, 172.3976, -5.438641, 0.122173),
(1581499026875, @OGUID+5905, 1, -1463.662, 168.5868, -7.74115, 5.305802),
(1581499026875, @OGUID+5887, 1, -1532.64, 209.9104, -7.928488, 2.024579),
(1581499026875, @OGUID+5894, 1, -1589.899, 164.8819, -6.098957, 3.228859),
(1581499026875, @OGUID+5889, 1, -1589.263, 158.8458, -6.063687, 2.268925),
(1581499026875, @OGUID+5907, 1, -1487.805, 208.9352, -7.792101, 5.619962),
(1581499026875, @OGUID+5904, 1, -1476.575, 196.8444, -7.792803, 0.6632232),
(1581499026875, @OGUID+5895, 1, -1591.423, 148.4819, -6.801592, 3.089183),
(1581499026875, @OGUID+5878, 1, -1571.76, 190.1771, -5.015974, 3.228859),
(1581499026875, @OGUID+5897, 1, -1496.323, 203.4045, -5.430457, 1.012289),
(1581499026875, @OGUID+5898, 1, -1617.413, 107.0941, -17.94824, 1.047198),
(1581499026875, @OGUID+5906, 1, -1477.01, 197.7799, -7.792803, 0.4363316),
(1581499027062, @OGUID+5929, 1, -1616.081, 127.7134, -17.57194, 5.393069),
(1581499027062, @OGUID+5938, 1, -1618.089, 100.5399, -16.89963, 5.253442),
(1581499027062, @OGUID+5918, 1, -1475.056, 201.6655, -7.792803, 4.572764),
(1581499027062, @OGUID+5910, 1, -1474.754, 198.7691, -7.917803, 1.221729),
(1581499027062, @OGUID+5915, 1, -1582.292, 100.9226, -9.762853, 4.97419),
(1581499027062, @OGUID+5942, 1, -1444.971, 214.8166, -7.75072, 0.3141584),
(1581499027062, @OGUID+5956, 1, -1308.958, 70.70155, 128.8397, 5.672322),
(1581499027062, @OGUID+5925, 1, -1611.672, 125.5455, -16.66829, 5.096362),
(1581499027062, @OGUID+5953, 1, -1636.687, 88.18826, -16.43352, 5.026549),
(1581499027062, @OGUID+5952, 1, -1642.39, 101.0805, -16.4149, 2.303831),
(1581499027062, @OGUID+5943, 1, -1449.432, 222.3142, -6.395928, 5.410522),
(1581499027062, @OGUID+5924, 1, -1493.464, 223.9403, -6.37694, 2.356195),
(1581499027062, @OGUID+5934, 1, -1613.565, 106.5597, -17.72129, 1.361356),
(1581499027062, @OGUID+5923, 1, -1455.819, 174.3352, -6.423319, 4.01426),
(1581499027062, @OGUID+5936, 1, -1625.418, 127.5017, -16.62185, 0.06981169),
(1581499027062, @OGUID+5947, 1, -1638.014, 116.6697, -17.89151, 5.532695),
(1581499027062, @OGUID+5922, 1, -1475.002, 206.0911, -7.792804, 3.071766),
(1581499027062, @OGUID+5944, 1, -1617.045, 87.51644, -16.6288, 4.32842),
(1581499027062, @OGUID+5940, 1, -1466.377, 232.9705, -6.379005, 6.056293),
(1581499027062, @OGUID+5928, 1, -1477.186, 221.6333, -7.746772, 4.625124),
(1581499027062, @OGUID+5914, 1, -1472.379, 196.724, -7.292803, 2.600535),
(1581499027062, @OGUID+5946, 1, -1618.758, 86.84432, -17.94824, 5.829401),
(1581499027062, @OGUID+5955, 1, -1324.485, 83.88734, 129.707, 0.3490652),
(1581499027062, @OGUID+5931, 1, -1455.809, 201.5383, -7.790167, 2.844883),
(1581499027062, @OGUID+5935, 1, -1458.394, 214.3719, -7.792798, 4.450591),
(1581499027062, @OGUID+5932, 1, -1446.113, 189.2778, -6.070208, 4.34587),
(1581499027062, @OGUID+5919, 1, -1474.985, 201.7063, -7.285859, 0.6632232),
(1581499027062, @OGUID+5909, 1, -1474.754, 198.7691, -7.917803, 1.221729),
(1581499027062, @OGUID+5908, 1, -1595.106, 122.6291, -12.66304, 4.293513),
(1581499027062, @OGUID+5926, 1, -1455.318, 191.7431, -5.450096, 1.117009),
(1581499027062, @OGUID+5950, 1, -1641.018, 103.7275, -17.94824, 3.804818),
(1581499027062, @OGUID+5949, 1, -1644.406, 112.6974, -15.91671, 4.118979),
(1581499027062, @OGUID+5920, 1, -1474.173, 201.1931, -7.792803, 4.520403),
(1581499027062, @OGUID+5941, 1, -1629.676, 122.1466, -17.94824, 4.956738),
(1581499027062, @OGUID+5927, 1, -1597.148, 98.94523, -11.76186, 5.009095),
(1581499027062, @OGUID+5916, 1, -1475.233, 201.5885, -7.278914, 5.340709),
(1581499027062, @OGUID+5951, 1, -1627.107, 80.43978, -16.52463, 3.194002),
(1581499027062, @OGUID+5911, 1, -1598.672, 184.7273, -3.619153, 4.502952),
(1581499027062, @OGUID+5913, 1, -1472.435, 196.713, -7.792803, 2.722713),
(1581499027062, @OGUID+5957, 1, -1298.268, 104.9622, 131.2188, 0.3316107),
(1581499027062, @OGUID+5930, 1, -1485.802, 231.1441, -5.233857, 0.6457717),
(1581499027062, @OGUID+5954, 1, -1326.533, 89.46688, 129.8198, 0.3665176),
(1581499027062, @OGUID+5917, 1, -1472.15, 197.6841, -7.792803, 2.722713),
(1581499027062, @OGUID+5939, 1, -1444.139, 206.059, -6.207995, 4.834563),
(1581499027062, @OGUID+5921, 1, -1468.202, 195.7496, -7.792795, 1.134463),
(1581499027062, @OGUID+5912, 1, -1475.913, 201.1984, -7.792803, 4.956738),
(1581499027062, @OGUID+5933, 1, -1464.705, 221.2604, -5.258084, 5.951575),
(1581499027062, @OGUID+5937, 1, -1626.319, 122.4444, -17.61427, 3.036838),
(1581499027062, @OGUID+5945, 1, -1636.011, 120.0071, -17.42741, 3.176533),
(1581499027062, @OGUID+5948, 1, -1626.451, 83.56036, -17.94824, 4.677484);

INSERT INTO `gameobject_destroy_time` (`unixtimems`, `guid`) VALUES
(1581499032297, @OGUID+5898),
(1581499032297, @OGUID+5934),
(1581499032297, @OGUID+5937);

INSERT INTO `gameobject_values_update` (`unixtimems`, `guid`, `flags`, `dynamic_flags`, `path_progress`, `state`, `artkit`, `custom_param`) VALUES
(1581499030172, @OGUID+5845, 1, NULL, NULL, 0, NULL, NULL),
(1581499031391, @OGUID+5845, 3, NULL, NULL, NULL, NULL, NULL),
(1581499032297, @OGUID+5845, 2, NULL, NULL, NULL, NULL, NULL),
(1581499063453, @OGUID+5845, 17, NULL, NULL, 1, NULL, NULL),
(1581499064250, @OGUID+5845, 1, NULL, NULL, NULL, NULL, NULL),
(1581499064656, @OGUID+5845, 0, NULL, NULL, NULL, NULL, NULL);

INSERT INTO `client_gameobject_use` (`unixtimems`, `guid`) VALUES
(1581499030031, @OGUID+5845);


INSERT INTO `spell_cast_start` (`unixtimems`, `caster_guid`, `caster_id`, `caster_type`, `caster_unit_guid`, `caster_unit_id`, `caster_unit_type`, `spell_id`, `visual_id`, `cast_time`, `cast_flags`, `cast_flags_ex`, `ammo_display_id`, `ammo_inventory_type`, `target_guid`, `target_id`, `target_type`) VALUES
(1581499062625, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 27880, 250874, 0, 11, 0, 0, 0, 0, 0, ''),
(1581499062625, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 24938, 0, 0, 11, 0, 0, 0, 0, 0, ''),
(1581499053437, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27746, 249676, 0, 262146, 0, 0, 0, 0, 0, ''),
(1581499052141, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27746, 249676, 0, 262146, 0, 0, 0, 0, 0, ''),
(1581499050797, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27746, 249676, 0, 262146, 0, 0, 0, 0, 0, ''),
(1581499050047, @CGUID+3999, 16121, 'Creature', @CGUID+3999, 16121, 'Creature', 27745, 251073, 0, 2, 1048576, 0, 0, 0, 0, ''),
(1581499050047, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25026, 0, 0, 262146, 0, 0, 0, 0, 0, ''),
(1581499049094, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25003, 249967, 0, 262146, 0, 0, 0, 0, 0, ''),
(1581499048203, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 24933, 249961, 0, 262146, 0, 0, 0, 0, 0, ''),
(1581499042125, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27746, 249676, 0, 262146, 0, 0, 0, 0, 0, ''),
(1581499039547, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25026, 0, 0, 262146, 0, 0, 0, 0, 0, ''),
(1581499039187, @CGUID+3998, 16121, 'Creature', @CGUID+3998, 16121, 'Creature', 27745, 251073, 0, 2, 1048576, 0, 0, 0, 0, ''),
(1581499037750, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25003, 249967, 0, 262146, 0, 0, 0, 0, 0, ''),
(1581499035937, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 24933, 249961, 0, 262146, 0, 0, 0, 0, 0, ''),
(1581499031078, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 24937, 250246, 0, 11, 0, 0, 0, @CGUID+3997, 15328, 'Creature'),
(1581499031078, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 24936, 0, 0, 2, 1048576, 0, 0, 0, 0, ''),
(1581499031078, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27749, 0, 0, 2, 1048576, 0, 0, 0, 0, ''),
(1581499030672, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 24934, 0, 0, 11, 0, 0, 0, 0, 0, ''),
(1581499030172, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 6247, 240504, 0, 262146, 0, 0, 0, @OGUID+5845, 180524, 'GameObject'),
(1581499026719, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 836, 236955, 0, 2, 0, 0, 0, 0, 0, '');

INSERT INTO `spell_cast_go` (`unixtimems`, `caster_guid`, `caster_id`, `caster_type`, `caster_unit_guid`, `caster_unit_id`, `caster_unit_type`, `spell_id`, `visual_id`, `cast_flags`, `cast_flags_ex`, `ammo_display_id`, `ammo_inventory_type`, `main_target_guid`, `main_target_id`, `main_target_type`, `hit_targets_count`, `hit_targets_list_id`, `miss_targets_count`, `miss_targets_list_id`, `src_position_id`, `dst_position_id`, `orientation`) VALUES
(1581499062625, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 27880, 250874, 265, 16, 0, 0, 0, 0, '', 1, 1, 0, 0, 0, 0, 0),
(1581499062625, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 24938, 0, 265, 16, 0, 0, 0, 0, '', 1, 2, 0, 0, 0, 0, 0),
(1581499062047, @CGUID+3991, 14822, 'Creature', @CGUID+3991, 14822, 'Creature', 23765, 248426, 264, 0, 0, 0, @PGUID+1885, 0, 'Player', 1, 3, 0, 0, 0, 0, 0),
(1581499053437, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27746, 249676, 264448, 16, 0, 0, 0, 0, '', 1, 4, 0, 0, 0, 0, 0),
(1581499052141, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27746, 249676, 264448, 16, 0, 0, 0, 0, '', 1, 5, 0, 0, 0, 0, 0),
(1581499050797, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27746, 249676, 264448, 16, 0, 0, 0, 0, '', 1, 6, 0, 0, 0, 0, 0),
(1581499050047, @CGUID+3999, 16121, 'Creature', @CGUID+3999, 16121, 'Creature', 27745, 251073, 17152, 1064976, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 1, 6.170985),
(1581499050047, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25026, 0, 262400, 16, 0, 0, 0, 0, '', 1, 7, 0, 0, 0, 0, 0),
(1581499049094, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25003, 249967, 262912, 16, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 2, 6.170985),
(1581499048203, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 24933, 249961, 262912, 16400, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0),
(1581499048203, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27766, 250507, 777, 16, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 3, 6.170985),
(1581499045578, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25032, 249851, 17156, 16384, 0, 0, 0, 0, '', 0, 0, 0, 0, 4, 0, 0),
(1581499044562, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25032, 249851, 17156, 16384, 0, 0, 0, 0, '', 0, 0, 0, 0, 5, 0, 0),
(1581499043578, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25032, 249851, 17156, 16384, 0, 0, 0, 0, '', 0, 0, 0, 0, 6, 0, 0),
(1581499042578, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25032, 249851, 17156, 16384, 0, 0, 0, 0, '', 0, 0, 0, 0, 7, 0, 0),
(1581499042125, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27746, 249676, 264448, 16, 0, 0, 0, 0, '', 1, 8, 0, 0, 0, 0, 0),
(1581499041562, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25032, 249851, 17156, 16384, 0, 0, 0, 0, '', 0, 0, 0, 0, 8, 0, 0),
(1581499040547, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25032, 249851, 17156, 16384, 0, 0, 0, 0, '', 0, 0, 0, 0, 9, 0, 0),
(1581499039547, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25026, 0, 262400, 16, 0, 0, 0, 0, '', 1, 9, 0, 0, 0, 0, 0),
(1581499039187, @CGUID+3998, 16121, 'Creature', @CGUID+3998, 16121, 'Creature', 27745, 251073, 17152, 1064976, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 10, 6.170985),
(1581499037750, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 25003, 249967, 262912, 16, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 11, 6.170985),
(1581499035937, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 24933, 249961, 262912, 16400, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0),
(1581499035937, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27766, 250507, 777, 16, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 12, 6.170985),
(1581499034656, @CGUID+3991, 14822, 'Creature', @CGUID+3991, 14822, 'Creature', 23767, 247042, 264, 0, 0, 0, @PGUID+1885, 0, 'Player', 1, 10, 0, 0, 0, 0, 0),
(1581499031078, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 24937, 250246, 265, 16, 0, 0, @CGUID+3997, 15328, 'Creature', 2, 11, 0, 0, 0, 0, 0),
(1581499031078, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 24936, 0, 256, 1048592, 0, 0, 0, 0, '', 1, 12, 0, 0, 0, 0, 0),
(1581499031078, @CGUID+3997, 15328, 'Creature', @CGUID+3997, 15328, 'Creature', 27749, 0, 256, 1048592, 0, 0, 0, 0, '', 1, 13, 0, 0, 0, 0, 0),
(1581499030672, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 24934, 0, 16649, 16, 0, 0, 0, 0, '', 1, 14, 0, 0, 0, 13, 0.2962068),
(1581499030172, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 6247, 240504, 262400, 16, 0, 0, @OGUID+5845, 180524, 'GameObject', 1, 15, 0, 0, 0, 0, 0),
(1581499026719, @PGUID+1882, 0, 'Player', @PGUID+1882, 0, 'Player', 836, 236955, 256, 16, 0, 0, 0, 0, '', 1, 16, 0, 0, 0, 0, 0);

INSERT INTO `spell_cast_go_target` (`list_id`, `target_guid`, `target_id`, `target_type`) VALUES
(1, @PGUID+1882, 0, 'Player'),
(2, @OGUID+5845, 180524, 'GameObject'),
(3, @PGUID+1885, 0, 'Player'),
(4, @CGUID+3997, 15328, 'Creature'),
(5, @CGUID+3997, 15328, 'Creature'),
(6, @CGUID+3997, 15328, 'Creature'),
(7, @CGUID+3997, 15328, 'Creature'),
(8, @CGUID+3997, 15328, 'Creature'),
(9, @CGUID+3997, 15328, 'Creature'),
(10, @PGUID+1885, 0, 'Player'),
(11, @CGUID+3997, 15328, 'Creature'),
(11, @PGUID+1882, 0, 'Player'),
(12, @CGUID+3997, 15328, 'Creature'),
(13, @CGUID+3997, 15328, 'Creature'),
(14, @OGUID+5845, 180524, 'GameObject'),
(15, @OGUID+5845, 180524, 'GameObject'),
(16, @PGUID+1882, 0, 'Player');

INSERT INTO `spell_cast_go_position` (`id`, `position_x`, `position_y`, `position_z`) VALUES
(1, -1498.708, 164.7282, -7.581925),
(2, -1498.708, 164.7282, -7.665259),
(3, -1503.677, 165.288, -7.667809),
(4, -1523.551, 167.5273, -7.792163),
(5, -1523.551, 167.5273, -7.792163),
(6, -1523.551, 167.5273, -7.792163),
(7, -1523.551, 167.5273, -7.792163),
(8, -1523.551, 167.5273, -7.792163),
(9, -1523.551, 167.5273, -7.792163),
(10, -1498.708, 164.7282, -7.581925),
(11, -1498.708, 164.7282, -7.665259),
(12, -1503.677, 165.288, -7.667809),
(13, -1524.387, 159.8109, -7.789398);

INSERT INTO `spell_channel_start` (`unixtimems`, `caster_guid`, `caster_id`, `caster_type`, `spell_id`, `visual_id`, `duration`) VALUES
(1581499031078, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581377118375, 0, 15891, 'Creature', 13540, 244595, -1),
(1581381800313, 0, 0, 'Player', 10187, 242125, 8000),
(1581381785016, 0, 0, 'Player', 10187, 242125, 8000),
(1581381775844, 0, 0, 'Player', 10187, 242125, 8000),
(1581473411578, 0, 0, 'Player', 7620, 241401, 30000),
(1581473399828, 0, 0, 'Player', 7620, 241401, 30000),
(1581473387328, 0, 0, 'Player', 7620, 241401, 30000),
(1581473368203, 0, 0, 'Player', 7620, 241401, 30000),
(1581473356641, 0, 0, 'Player', 7620, 241401, 30000),
(1581473346797, 0, 0, 'Player', 7620, 241401, 30000),
(1581473319344, 0, 0, 'Player', 7620, 241401, 30000),
(1581473297797, 0, 0, 'Player', 7620, 241401, 30000),
(1581473285094, 0, 0, 'Player', 7620, 241401, 30000),
(1581473269094, 0, 0, 'Player', 7620, 241401, 30000),
(1581473244672, 0, 0, 'Player', 7620, 241401, 30000),
(1581473231438, 0, 0, 'Player', 7620, 241401, 30000),
(1581473204657, 0, 0, 'Player', 7620, 241401, 30000),
(1581473176610, 0, 0, 'Player', 7620, 241401, 30000),
(1581473161000, 0, 0, 'Player', 7620, 241401, 30000),
(1581473149828, 0, 0, 'Player', 7620, 241401, 30000),
(1581473132391, 0, 0, 'Player', 7620, 241401, 30000),
(1581473118375, 0, 0, 'Player', 7620, 241401, 30000),
(1581473097844, 0, 0, 'Player', 7620, 241401, 30000),
(1581473080782, 0, 0, 'Player', 7620, 241401, 30000),
(1581473068625, 0, 0, 'Player', 7620, 241401, 30000),
(1581473044141, 0, 0, 'Player', 7620, 241401, 30000),
(1581473026032, 0, 0, 'Player', 7620, 241401, 30000),
(1581471711125, 0, 15891, 'Creature', 13540, 244595, -1),
(1581448925640, 0, 5862, 'Creature', 21157, 247832, -1),
(1581448924828, 0, 8419, 'Creature', 8734, 242165, -1),
(1581448924828, 0, 5862, 'Creature', 21157, 247832, -1),
(1581447383000, 0, 11325, 'Creature', 19231, 246991, 300000),
(1581447322984, 0, 11325, 'Creature', 19231, 246991, 300000),
(1581446842937, 0, 11325, 'Creature', 19231, 246991, 300000),
(1581446788406, 0, 0, 'Player', 12051, 243947, 8000),
(1581446752922, 0, 11325, 'Creature', 19231, 246991, 300000),
(1581446722875, 0, 11325, 'Creature', 19231, 246991, 300000),
(1581446662875, 0, 11325, 'Creature', 19231, 246991, 300000),
(1581446415297, 0, 0, 'Player', 7620, 241401, 30000),
(1581446207047, 0, 0, 'Player', 7620, 241401, 30000),
(1581446184234, 0, 0, 'Player', 7620, 241401, 30000),
(1581445972750, 0, 11325, 'Creature', 19231, 246991, 300000),
(1581445942672, 0, 11325, 'Creature', 19231, 246991, 300000),
(1581443299547, 0, 0, 'Player', 7620, 241401, 30000),
(1581443156875, 0, 0, 'Player', 7620, 241401, 30000),
(1581443144312, 0, 0, 'Player', 7620, 241401, 30000),
(1581443132062, 0, 0, 'Player', 7620, 241401, 30000),
(1581458761781, 0, 0, 'Player', 12051, 243947, 8000),
(1581458272172, 0, 0, 'Player', 12051, 243947, 8000),
(1581458188734, 0, 0, 'Player', 12051, 243947, 8000),
(1581458128297, 0, 0, 'Player', 12051, 243947, 8000),
(1581458032016, 0, 0, 'Player', 12051, 243947, 8000),
(1581457605156, 0, 0, 'Player', 12051, 243947, 8000),
(1581457291219, 0, 0, 'Player', 10187, 242125, 8000),
(1581376310000, 0, 0, 'Player', 24937, 250246, 300000),
(1581375548797, 0, 0, 'Player', 24937, 250246, 300000),
(1581375520968, 0, 0, 'Player', 24937, 250246, 300000),
(1581375489031, 0, 0, 'Player', 24937, 250246, 300000),
(1581375277343, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581375219484, 0, 0, 'Player', 24937, 250246, 300000),
(1581375210968, 0, 0, 'Player', 24937, 250246, 300000),
(1581375184750, 0, 0, 'Player', 24937, 250246, 300000),
(1581375179093, 0, 0, 'Player', 24937, 250246, 300000),
(1581373903718, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581573043844, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581573036079, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581573028110, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581573020000, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581573011547, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581573002657, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581572985704, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581572975219, @PGUID+1882, 0, 'Player', 24937, 250246, 300000),
(1581572959891, @PGUID+1882, 0, 'Player', 24937, 250246, 300000);

INSERT INTO `spell_channel_update` (`unixtimems`, `caster_guid`, `caster_id`, `caster_type`, `duration`) VALUES
(1581499068297, @CGUID+3997, 15328, 'Creature', 0),
(1581499063031, @CGUID+3997, 15328, 'Creature', 0),
(1581499062625, @PGUID+1882, 0, 'Player', 0),
(1581499051328, @CGUID+3999, 16121, 'Creature', 0),
(1581499040391, @CGUID+3998, 16121, 'Creature', 0),
(1581499031078, @PGUID+1882, 0, 'Player', 0),
(1581377122453, 0, 15891, 'Creature', 0),
(1581377122047, 0, 15891, 'Creature', 0),
(1581377119094, @PGUID+1882, 0, 'Player', 0),
(1581377118375, 0, 15891, 'Creature', 0),
(1581381800313, 0, 0, 'Player', 0),
(1581381794672, 0, 0, 'Player', 0),
(1581381785016, 0, 0, 'Player', 0),
(1581381784500, 0, 0, 'Player', 0),
(1581381775844, 0, 0, 'Player', 0),
(1581381649781, @PGUID+1882, 0, 'Player', 0),
(1581494339531, 0, 5873, 'Creature', 0),
(1581494324985, 0, 3035, 'Creature', 0),
(1581494314438, 0, 3035, 'Creature', 0),
(1581573054266, 0, 15328, 'Creature', 0),
(1581573054266, @PGUID+1882, 0, 'Player', 0),
(1581573043844, @PGUID+1882, 0, 'Player', 0),
(1581573043000, 0, 15328, 'Creature', 0),
(1581573039329, 0, 15328, 'Creature', 0),
(1581573039094, @PGUID+1882, 0, 'Player', 0),
(1581573036079, @PGUID+1882, 0, 'Player', 0),
(1581573036079, 0, 15328, 'Creature', 0),
(1581573031235, 0, 15328, 'Creature', 0),
(1581573031235, @PGUID+1882, 0, 'Player', 0),
(1581573028110, @PGUID+1882, 0, 'Player', 0),
(1581573028110, 0, 15328, 'Creature', 0),
(1581573023641, 0, 15328, 'Creature', 0),
(1581573023250, @PGUID+1882, 0, 'Player', 0),
(1581573020000, @PGUID+1882, 0, 'Player', 0),
(1581573018407, 0, 15328, 'Creature', 0),
(1581573015172, 0, 15328, 'Creature', 0),
(1581573014766, @PGUID+1882, 0, 'Player', 0),
(1581573011547, @PGUID+1882, 0, 'Player', 0),
(1581573011141, 0, 15328, 'Creature', 0),
(1581573006297, 0, 15328, 'Creature', 0),
(1581573006204, @PGUID+1882, 0, 'Player', 0),
(1581573003375, 0, 15328, 'Creature', 0),
(1581573002657, @PGUID+1882, 0, 'Player', 0),
(1581572998594, 0, 15328, 'Creature', 0),
(1581572998438, @PGUID+1882, 0, 'Player', 0),
(1581572985704, @PGUID+1882, 0, 'Player', 0),
(1581572985704, 0, 15328, 'Creature', 0),
(1581572980860, 0, 15328, 'Creature', 0),
(1581572980719, @PGUID+1882, 0, 'Player', 0),
(1581572975219, @PGUID+1882, 0, 'Player', 0),
(1581572975219, 0, 15328, 'Creature', 0),
(1581572969954, 0, 15328, 'Creature', 0),
(1581572969954, @PGUID+1882, 0, 'Player', 0),
(1581572959891, @PGUID+1882, 0, 'Player', 0),
(1581473411578, 0, 0, 'Player', 0),
(1581473409985, 0, 0, 'Player', 0),
(1581473399828, 0, 0, 'Player', 0),
(1581473397047, 0, 0, 'Player', 0),
(1581473387328, 0, 0, 'Player', 0),
(1581473385703, 0, 0, 'Player', 0),
(1581473368203, 0, 0, 'Player', 0),
(1581473365032, 0, 0, 'Player', 0),
(1581473356641, 0, 0, 'Player', 0),
(1581473354891, 0, 0, 'Player', 0),
(1581473346797, 0, 0, 'Player', 0),
(1581473345172, 0, 0, 'Player', 0),
(1581473319344, 0, 0, 'Player', 0),
(1581473317157, 0, 0, 'Player', 0),
(1581473297797, 0, 0, 'Player', 0),
(1581473295625, 0, 0, 'Player', 0),
(1581473285094, 0, 0, 'Player', 0),
(1581473282266, 0, 0, 'Player', 0),
(1581473269094, 0, 0, 'Player', 0),
(1581473265266, 0, 0, 'Player', 0),
(1581473244672, 0, 0, 'Player', 0),
(1581473241766, 0, 0, 'Player', 0),
(1581473231438, 0, 0, 'Player', 0),
(1581473229610, 0, 0, 'Player', 0),
(1581473204657, 0, 0, 'Player', 0),
(1581473202813, 0, 0, 'Player', 0),
(1581473176610, 0, 0, 'Player', 0),
(1581473173625, 0, 0, 'Player', 0),
(1581473161000, 0, 0, 'Player', 0),
(1581473159422, 0, 0, 'Player', 0),
(1581473149828, 0, 0, 'Player', 0),
(1581473147657, 0, 0, 'Player', 0),
(1581473132391, 0, 0, 'Player', 0),
(1581473129407, 0, 0, 'Player', 0),
(1581473118375, 0, 0, 'Player', 0),
(1581473115235, 0, 0, 'Player', 0),
(1581473097844, 0, 0, 'Player', 0),
(1581473095766, 0, 0, 'Player', 0),
(1581473080782, 0, 0, 'Player', 0),
(1581473079172, 0, 0, 'Player', 0),
(1581473068625, 0, 0, 'Player', 0),
(1581473066610, 0, 0, 'Player', 0),
(1581473044141, 0, 0, 'Player', 0),
(1581473041907, 0, 0, 'Player', 0),
(1581473026032, 0, 0, 'Player', 0),
(1581473017563, 0, 0, 'Player', 0),
(1581473014328, @PGUID+1882, 0, 'Player', 0),
(1581472951469, 0, 0, 'Player', 0),
(1581472836891, 0, 4721, 'Creature', 0),
(1581471983610, @PGUID+1882, 0, 'Player', 0),
(1581471807391, @PGUID+1882, 0, 'Player', 0),
(1581471715235, 0, 15891, 'Creature', 0),
(1581471714360, 0, 15891, 'Creature', 0),
(1581471711969, 0, 0, 'Player', 0),
(1581471711125, 0, 15891, 'Creature', 0),
(1581471704703, 0, 416, 'Pet', 0),
(1581471355157, 0, 0, 'Player', 0),
(1581470780922, 0, 5729, 'Creature', 0),
(1581470240625, 0, 5736, 'Creature', 0),
(1581470154891, 0, 5727, 'Creature', 0),
(1581470088391, 0, 3475, 'Pet', 0),
(1581469991828, 0, 0, 'Player', 0),
(1581469990735, 0, 416, 'Pet', 0),
(1581469904641, 0, 3475, 'Pet', 0),
(1581469899282, 0, 3619, 'Pet', 0),
(1581469898110, @PGUID+1882, 0, 'Player', 0),
(1581376310000, 0, 0, 'Player', 0),
(1581375624828, 0, 5923, 'Creature', 0),
(1581375573453, 0, 15328, 'Creature', 0),
(1581375573187, 0, 0, 'Player', 0),
(1581375562953, 0, 15328, 'Creature', 0),
(1581375559687, 0, 15328, 'Creature', 0),
(1581375559547, 0, 0, 'Player', 0),
(1581375548797, 0, 0, 'Player', 0),
(1581375527781, 0, 7550, 'Creature', 0),
(1581375520968, 0, 0, 'Player', 0),
(1581375509265, 0, 15328, 'Creature', 0),
(1581375504406, 0, 15328, 'Creature', 0),
(1581375504000, 0, 0, 'Player', 0),
(1581375489031, 0, 0, 'Player', 0),
(1581375346187, 0, 15328, 'Creature', 0),
(1581375340531, 0, 15328, 'Creature', 0),
(1581375340406, @PGUID+1882, 0, 'Player', 0),
(1581375323562, 0, 15328, 'Creature', 0),
(1581375321922, 0, 16121, 'Creature', 0),
(1581375319515, 0, 0, 'Player', 0),
(1581375319406, 0, 15328, 'Creature', 0),
(1581375318297, 0, 16121, 'Creature', 0),
(1581375311000, 0, 16121, 'Creature', 0),
(1581375306562, 0, 15368, 'Creature', 0),
(1581375305703, 0, 16121, 'Creature', 0),
(1581375303312, 0, 15368, 'Creature', 0),
(1581375297625, 0, 16121, 'Creature', 0),
(1581375288687, 0, 16121, 'Creature', 0),
(1581375287875, 0, 16121, 'Creature', 0),
(1581375281406, 0, 15328, 'Creature', 0),
(1581375277343, @PGUID+1882, 0, 'Player', 0),
(1581375276937, 0, 0, 'Player', 0),
(1581375276640, 0, 15328, 'Creature', 0),
(1581375257500, 0, 16121, 'Creature', 0),
(1581375240093, 0, 16121, 'Creature', 0),
(1581375219484, 0, 0, 'Player', 0),
(1581375217047, 0, 15328, 'Creature', 0),
(1581375212187, 0, 15328, 'Creature', 0),
(1581375211781, 0, 0, 'Player', 0),
(1581375210968, 0, 0, 'Player', 0),
(1581375184750, 0, 0, 'Player', 0),
(1581375184750, 0, 15328, 'Creature', 0),
(1581375180297, 0, 15328, 'Creature', 0),
(1581375180297, 0, 0, 'Player', 0),
(1581375179093, 0, 0, 'Player', 0),
(1581374446640, 0, 0, 'Player', 0),
(1581373993000, 0, 0, 'Player', 0),
(1581373950578, 0, 15328, 'Creature', 0),
(1581373946140, 0, 15328, 'Creature', 0),
(1581373945968, @PGUID+1882, 0, 'Player', 0),
(1581373914265, 0, 16121, 'Creature', 0),
(1581373903718, @PGUID+1882, 0, 'Player', 0),
(1581373866109, 0, 14867, 'Creature', 0),
(1581463780547, 0, 0, 'Player', 0),
(1581463780547, @PGUID+1882, 0, 'Player', 0),
(1581463680500, 0, 3226, 'Creature', 0),
(1581463482390, 0, 416, 'Pet', 0),
(1581463298015, 0, 9696, 'Pet', 0),
(1581463287797, 0, 16085, 'Creature', 0),
(1581463287625, 0, 14430, 'Pet', 0),
(1581463282875, 0, 0, 'Player', 0),
(1581462771625, 0, 0, 'Player', 0),
(1581454948078, 0, 16110, 'Creature', 0),
(1581453910718, 0, 0, 'Player', 0),
(1581452162406, 0, 417, 'Pet', 0),
(1581451181343, 0, 0, 'Player', 0),
(1581449025687, 0, 946, 'Creature', 0),
(1581449023281, 0, 1397, 'Creature', 0),
(1581448925640, 0, 5862, 'Creature', 0),
(1581448924828, 0, 8419, 'Creature', 0),
(1581448747125, 0, 1860, 'Pet', 0),
(1581448661172, 0, 0, 'Player', 0),
(1581448612312, 0, 0, 'Player', 0),
(1581448560906, 0, 0, 'Player', 0),
(1581448532922, 0, 10259, 'Creature', 0),
(1581448532500, 0, 2850, 'Pet', 0),
(1581448327859, 0, 0, 'Player', 0),
(1581448209562, 0, 5043, 'Creature', 0),
(1581448207468, 0, 5043, 'Creature', 0),
(1581448206812, 0, 5043, 'Creature', 0),
(1581448205453, 0, 5043, 'Creature', 0),
(1581448204734, 0, 5043, 'Creature', 0),
(1581448202359, 0, 5043, 'Creature', 0),
(1581448201062, 0, 5043, 'Creature', 0),
(1581448198672, 0, 5043, 'Creature', 0),
(1581448195781, 0, 0, 'Player', 0),
(1581448191406, 0, 0, 'Player', 0),
(1581448183203, 0, 0, 'Player', 0),
(1581448171500, 0, 0, 'Player', 0),
(1581448161859, 0, 0, 'Player', 0),
(1581448152500, 0, 0, 'Player', 0),
(1581448148453, 0, 0, 'Player', 0),
(1581448129062, 0, 0, 'Player', 0),
(1581448109578, 0, 0, 'Player', 0),
(1581448092968, 0, 0, 'Player', 0),
(1581448082047, 0, 0, 'Player', 0),
(1581448080062, 0, 0, 'Player', 0),
(1581447941609, 0, 0, 'Player', 0),
(1581447814859, 0, 0, 'Player', 0),
(1581447790187, 0, 0, 'Player', 0),
(1581447766328, 0, 0, 'Player', 0),
(1581447571203, 0, 0, 'Player', 0),
(1581447485828, 0, 0, 'Player', 0),
(1581447393187, 0, 9696, 'Pet', 0),
(1581447383000, 0, 11325, 'Creature', 0),
(1581447361672, 0, 0, 'Player', 0),
(1581447322984, 0, 11325, 'Creature', 0),
(1581447176703, 0, 0, 'Player', 0),
(1581447135437, 0, 16111, 'Creature', 0),
(1581447126875, 0, 0, 'Player', 0),
(1581447080375, 0, 417, 'Pet', 0),
(1581447023109, 0, 416, 'Pet', 0),
(1581446996125, 0, 16111, 'Creature', 0),
(1581446981515, 0, 9696, 'Pet', 0),
(1581446938172, 0, 5043, 'Creature', 0),
(1581446924453, 0, 5043, 'Creature', 0),
(1581446922797, 0, 5043, 'Creature', 0),
(1581446922468, 0, 5043, 'Creature', 0),
(1581446921640, 0, 5043, 'Creature', 0),
(1581446917047, 0, 6237, 'Creature', 0),
(1581446914312, 0, 5043, 'Creature', 0),
(1581446912703, 0, 0, 'Player', 0),
(1581446842937, 0, 11325, 'Creature', 0),
(1581446805468, 0, 16111, 'Creature', 0),
(1581446796468, 0, 0, 'Player', 0),
(1581446788406, 0, 0, 'Player', 0),
(1581446755156, 0, 0, 'Player', 0),
(1581446752922, 0, 11325, 'Creature', 0),
(1581446744265, 0, 11325, 'Creature', 0),
(1581446738234, 0, 2385, 'Pet', 0);

INSERT INTO `spell_channel_update` (`unixtimems`, `caster_guid`, `caster_id`, `caster_type`, `duration`) VALUES
(1581446722875, 0, 11325, 'Creature', 0),
(1581446666578, 0, 0, 'Player', 0),
(1581446662875, 0, 11325, 'Creature', 0),
(1581446656500, 0, 0, 'Player', 0),
(1581446656078, 0, 16111, 'Creature', 0),
(1581446583984, 0, 1412, 'Creature', 0),
(1581446506672, 0, 0, 'Player', 0),
(1581446415297, 0, 0, 'Player', 0),
(1581446413125, 0, 0, 'Player', 0),
(1581446238578, 0, 0, 'Player', 0),
(1581446207047, 0, 0, 'Player', 0),
(1581446204687, 0, 0, 'Player', 0),
(1581446184234, 0, 0, 'Player', 0),
(1581446172265, 0, 0, 'Player', 0),
(1581445972750, 0, 11325, 'Creature', 0),
(1581445942672, 0, 11325, 'Creature', 0),
(1581445930515, 0, 9696, 'Pet', 0),
(1581445851593, 0, 16085, 'Creature', 0),
(1581445832984, 0, 0, 'Player', 0),
(1581445829797, 0, 0, 'Player', 0),
(1581445603718, 0, 0, 'Player', 0),
(1581444749875, 0, 0, 'Player', 0),
(1581444563297, 0, 0, 'Player', 0),
(1581444532968, 0, 0, 'Player', 0),
(1581444515125, 0, 0, 'Player', 0),
(1581444496890, 0, 0, 'Player', 0),
(1581444085703, 0, 0, 'Player', 0),
(1581443881109, 0, 0, 'Player', 0),
(1581443874250, 0, 0, 'Player', 0),
(1581443299547, 0, 0, 'Player', 0),
(1581443297578, 0, 0, 'Player', 0),
(1581443182500, 0, 583, 'Creature', 0),
(1581443156875, 0, 0, 'Player', 0),
(1581443155093, 0, 0, 'Player', 0),
(1581443144312, 0, 0, 'Player', 0),
(1581443142125, 0, 0, 'Player', 0),
(1581443132062, 0, 0, 'Player', 0),
(1581443129531, 0, 0, 'Player', 0),
(1581443106172, 0, 16111, 'Creature', 0),
(1581443102468, 0, 416, 'Pet', 0),
(1581443027297, 0, 5708, 'Pet', 0),
(1581442941422, 0, 0, 'Player', 0),
(1581442937406, 0, 0, 'Player', 0),
(1581461928063, 0, 0, 'Player', 0),
(1581461822359, 0, 0, 'Player', 0),
(1581461821141, 0, 0, 'Player', 0),
(1581461302984, 0, 0, 'Player', 0),
(1581461291688, 0, 4262, 'Creature', 0),
(1581461250375, 0, 0, 'Player', 0),
(1581460451031, 0, 0, 'Player', 0),
(1581460401609, 0, 0, 'Player', 0),
(1581460363984, 0, 4262, 'Creature', 0),
(1581460322719, 0, 0, 'Player', 0),
(1581460264016, 0, 0, 'Player', 0),
(1581460255406, 0, 0, 'Player', 0),
(1581460253672, 0, 0, 'Player', 0),
(1581460169422, 0, 0, 'Player', 0),
(1581460164984, 0, 0, 'Player', 0),
(1581460012328, 0, 547, 'Pet', 0),
(1581459984797, 0, 0, 'Player', 0),
(1581459723844, 0, 0, 'Player', 0),
(1581459666219, 0, 0, 'Player', 0),
(1581459481063, 0, 0, 'Player', 0),
(1581459251797, 0, 0, 'Player', 0),
(1581459184922, 0, 0, 'Player', 0),
(1581459148047, 0, 0, 'Player', 0),
(1581459131453, 0, 0, 'Player', 0),
(1581459080719, 0, 416, 'Pet', 0),
(1581458991813, 0, 0, 'Player', 0),
(1581458991391, 0, 0, 'Player', 0),
(1581458905625, 0, 0, 'Player', 0),
(1581458883781, 0, 0, 'Player', 0),
(1581458769719, 0, 0, 'Player', 0),
(1581458761781, 0, 0, 'Player', 0),
(1581458659875, 0, 2033, 'Pet', 0),
(1581458611266, 0, 0, 'Player', 0),
(1581458554969, 0, 0, 'Player', 0),
(1581458475984, 0, 0, 'Player', 0),
(1581458436219, 0, 1860, 'Pet', 0),
(1581458415641, 0, 1860, 'Pet', 0),
(1581458344344, 0, 0, 'Player', 0),
(1581458333781, 0, 0, 'Player', 0),
(1581458302234, 0, 0, 'Player', 0),
(1581458280172, 0, 0, 'Player', 0),
(1581458272172, 0, 0, 'Player', 0),
(1581458263781, 0, 0, 'Player', 0),
(1581458256844, 0, 2850, 'Pet', 0),
(1581458197797, 0, 0, 'Player', 0),
(1581458196797, 0, 0, 'Player', 0),
(1581458188734, 0, 0, 'Player', 0),
(1581458186047, 0, 0, 'Player', 0),
(1581458152453, 0, 0, 'Player', 0),
(1581458136359, 0, 0, 'Player', 0),
(1581458128297, 0, 0, 'Player', 0),
(1581458040047, 0, 0, 'Player', 0),
(1581458032016, 0, 0, 'Player', 0),
(1581458028516, 0, 0, 'Player', 0),
(1581457932969, 0, 1860, 'Pet', 0),
(1581457913969, 0, 0, 'Player', 0),
(1581457860859, 0, 0, 'Player', 0),
(1581457841906, 0, 0, 'Player', 0),
(1581457830109, 0, 0, 'Player', 0),
(1581457826891, 0, 0, 'Player', 0),
(1581457810734, 0, 0, 'Player', 0),
(1581457788859, 0, 0, 'Player', 0),
(1581457727313, 0, 16111, 'Creature', 0),
(1581457681922, 0, 0, 'Player', 0),
(1581457671000, 0, 0, 'Player', 0),
(1581457668250, 0, 0, 'Player', 0),
(1581457659359, 0, 0, 'Player', 0),
(1581457636578, 0, 0, 'Player', 0),
(1581457625328, 0, 0, 'Player', 0),
(1581457613109, 0, 0, 'Player', 0),
(1581457608672, 0, 0, 'Player', 0),
(1581457605156, 0, 0, 'Player', 0),
(1581457604641, 0, 0, 'Player', 0),
(1581457579891, 0, 0, 'Player', 0),
(1581457302109, 0, 416, 'Pet', 0),
(1581457300891, 0, 0, 'Player', 0),
(1581457291219, 0, 0, 'Player', 0),
(1581456904859, 0, 1860, 'Pet', 0),
(1581456788547, 0, 0, 'Player', 0),
(1581456755391, 0, 0, 'Player', 0),
(1581456567578, 0, 7560, 'Creature', 0),
(1581456319094, 0, 0, 'Player', 0),
(1581456275406, 0, 0, 'Player', 0);

DELETE FROM `creature_pet_actions` WHERE `entry`=15328;
INSERT INTO `creature_pet_actions` (`entry`, `slot1`, `slot2`, `slot3`, `slot4`, `slot5`, `slot6`, `slot7`, `slot8`, `slot9`, `slot10`) VALUES
(15328, 2, 0, 0, 24933, 25003, 25026, 27746, 0, 0, 0);


DELETE FROM `creature_stats` WHERE (`entry`=15328 AND `level`=2);
INSERT INTO `creature_stats` (`entry`, `level`, `dmg_min`, `dmg_max`, `offhand_dmg_min`, `offhand_dmg_max`, `ranged_dmg_min`, `ranged_dmg_max`, `attack_power`, `positive_attack_power`, `negative_attack_power`, `attack_power_multiplier`, `ranged_attack_power`, `positive_ranged_attack_power`, `negative_ranged_attack_power`, `ranged_attack_power_multiplier`, `base_health`, `base_mana`, `strength`, `agility`, `stamina`, `intellect`, `spirit`, `positive_strength`, `positive_agility`, `positive_stamina`, `positive_intellect`, `positive_spirit`, `negative_strength`, `negative_agility`, `negative_stamina`, `negative_intellect`, `negative_spirit`, `armor`, `holy_res`, `fire_res`, `nature_res`, `frost_res`, `shadow_res`, `arcane_res`, `positive_armor`, `positive_holy_res`, `positive_fire_res`, `positive_nature_res`, `positive_frost_res`, `positive_shadow_res`, `positive_arcane_res`, `negative_armor`, `negative_holy_res`, `negative_fire_res`, `negative_nature_res`, `negative_frost_res`, `negative_shadow_res`, `negative_arcane_res`) VALUES
(15328, 2, 1.996592, 2.309173, 0.9982958, 1.154587, 1.882306, 2.194887, 24, 0, 0, 0, 22, 0, 0, 0, 26, 64, 22, 21, 23, 20, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21, 0, 0, 0, 0, 0, 0, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); -- 15328


DELETE FROM `creature_text_template` WHERE (`entry`=15328 AND `group_id`=0);
INSERT INTO `creature_text_template` (`entry`, `group_id`, `text`, `chat_type`, `language`, `emote`, `sound`, `broadcast_text_id`, `comment`) VALUES
(15328, 0, 'Use your tonk action bar above your standard action bar to attack other tonks.', 15, 0, 0, 0, 0, 'Steam Tonk to Player');
INSERT INTO `creature_text` (`unixtimems`, `guid`, `entry`, `group_id`, `health_percent`) VALUES
(1581499031391, @CGUID+3997, 15328, 0, 100); -- 15328


DELETE FROM `play_music` WHERE (`music`=8440 AND `unixtimems` IN (1581499069922,1581499068703,1581499067500,1581499066266,1581499065047,1581499063844,1581499062625,1581499061437,1581499060203,1581499059000,1581499057781,1581499056578,1581499055359,1581499054078,1581499052891,1581499051734,1581499050531,1581499049312,1581499048109,1581499046875,1581499045672,1581499044453,1581499043234,1581499042016,1581499040812,1581499039547,1581499038375,1581499037156,1581499035937,1581499034656,1581499033516,1581499032297,1581499031078,1581499029844,1581499028641,1581499027437));
INSERT INTO `play_music` (`unixtimems`, `music`) VALUES
(1581499069922, 8440), -- 8440
(1581499068703, 8440), -- 8440
(1581499067500, 8440), -- 8440
(1581499066266, 8440), -- 8440
(1581499065047, 8440), -- 8440
(1581499063844, 8440), -- 8440
(1581499062625, 8440), -- 8440
(1581499061437, 8440), -- 8440
(1581499060203, 8440), -- 8440
(1581499059000, 8440), -- 8440
(1581499057781, 8440), -- 8440
(1581499056578, 8440), -- 8440
(1581499055359, 8440), -- 8440
(1581499054078, 8440), -- 8440
(1581499052891, 8440), -- 8440
(1581499051734, 8440), -- 8440
(1581499050531, 8440), -- 8440
(1581499049312, 8440), -- 8440
(1581499048109, 8440), -- 8440
(1581499046875, 8440), -- 8440
(1581499045672, 8440), -- 8440
(1581499044453, 8440), -- 8440
(1581499043234, 8440), -- 8440
(1581499042016, 8440), -- 8440
(1581499040812, 8440), -- 8440
(1581499039547, 8440), -- 8440
(1581499038375, 8440), -- 8440
(1581499037156, 8440), -- 8440
(1581499035937, 8440), -- 8440
(1581499034656, 8440), -- 8440
(1581499033516, 8440), -- 8440
(1581499032297, 8440), -- 8440
(1581499031078, 8440), -- 8440
(1581499029844, 8440), -- 8440
(1581499028641, 8440), -- 8440
(1581499027437, 8440); -- 8440


